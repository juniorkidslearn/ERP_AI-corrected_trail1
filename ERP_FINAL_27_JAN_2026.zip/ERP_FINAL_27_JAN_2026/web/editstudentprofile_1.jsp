<%@ page import="java.sql.*" %>
<%@ include file="auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    String message = null;
    boolean isError = false;

    Connection conn = null;
    PreparedStatement pstmt = null;

    if ("POST".equalsIgnoreCase(request.getMethod())) {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String currentPassword = request.getParameter("current_password");
            String newPassword = request.getParameter("new_password");
            String confirmPassword = request.getParameter("confirm_password");
            String email = request.getParameter("email");
            String mobile = request.getParameter("mobile");
            String city = request.getParameter("city");

            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Get current password from DB
            pstmt = conn.prepareStatement("SELECT passord FROM studentMaster WHERE id=?");
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String dbPassword = rs.getString("passord");

                if (dbPassword.equals(currentPassword)) {
                    // Current password matches, proceed with updates
                    
                    String passwordToUpdate = dbPassword; // By default, keep the old password

                    if (newPassword != null && !newPassword.isEmpty()) {
                        if (newPassword.equals(confirmPassword)) {
                            passwordToUpdate = newPassword;
                        } else {
                            message = "New passwords do not match.";
                            isError = true;
                        }
                    }

                    if (!isError) { // Only update if no password mismatch
                        pstmt = conn.prepareStatement("UPDATE studentMaster SET passord=?, email=?, mobile=?, city=? WHERE id=?");
                        pstmt.setString(1, passwordToUpdate);
                        pstmt.setString(2, email);
                        pstmt.setString(3, mobile);
                        pstmt.setString(4, city);
                        pstmt.setInt(5, id);

                        int rowsAffected = pstmt.executeUpdate();
                        if (rowsAffected > 0) {
                            message = "Your details have been updated successfully!";
                        } else {
                            message = "Failed to update your details. Please try again.";
                            isError = true;
                        }
                    }

                } else {
                    message = "Incorrect current password. Profile not updated.";
                    isError = true;
                }
            } else {
                message = "Student user not found.";
                isError = true;
            }

        } catch (Exception e) {
            message = "An error occurred during modification: " + e.getMessage();
            isError = true;
        } finally {
            closeQuietly(pstmt);
            closeQuietly(conn);
        }
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Status | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="home.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages.jsp" class="active">Home</a></li>
            <li><a href="pending_fee.jsp">Pending Fee</a></li>
            <li><a href="profile.jsp">My Enrollments</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% if (message != null) { %>
            <div class="form-container text-center" style="border-color: <%= isError ? "red" : "green" %>;">
                <h2 style="color: <%= isError ? "red" : "green" %>;"><%= isError ? "Update Failed" : "Update Successful" %></h2>
                <p><%= message %></p>
                <% if (isError) { %>
                    <a href="editstudentprofile.jsp?id=<%= request.getParameter("id") %>" class="btn">Try Again</a>
                <% } else { %>
                    <a href="DisplayMessages.jsp" class="btn">Go to Home</a>
                <% } %>
            </div>
        <% } else {
            response.sendRedirect("DisplayMessages.jsp");
        }
        %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</body>
</html>
