<%-- 
    Document   : DisplayMessages
    Created on : Dec 15, 2018, 10:50:00 AM
    Author     : HP
--%>

<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.Statement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.PreparedStatement" %>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="home.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages.jsp" class="active">Home</a></li>
            <li><a href="pending_fee.jsp">Pending Fee</a></li>
            <li><a href="profile.jsp">My Enrollments</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <%@ include file="auth.jsp" %>
        <% 
         String name=(String)session.getAttribute("username");
        %>
        <h2 class="text-center">Welcome <%=name%></h2>

        <% 
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String errorMessage = null;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

                // --- 1. Fetch Student Personal Information ---
                String personalQuery = "SELECT id, name, passord, email, mobile, city FROM studentMaster WHERE name = ?";
                pstmt = conn.prepareStatement(personalQuery);
                pstmt.setString(1, name);
                rs = pstmt.executeQuery();

                if (rs.next()) {
        %>
                <div class="form-container">
                    <h3 class="text-center">Personal Details</h3>
                    <table class="content-table">
                        <tbody>
                            <tr>
                                <th>Name</th>
                                <td><%= rs.getString("name") %></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><%= rs.getString("email") %></td>
                            </tr>
                            <tr>
                                <th>Mobile</th>
                                <td><%= rs.getString("mobile") %></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><%= rs.getString("city") %></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="form-group text-center">
                        <button type="button" class="btn" onclick="location.href='editstudentprofile.jsp?id=<%= rs.getInt("id") %>'">Edit Profile</button>
                    </div>
                </div>
                <br>
        <%
                } else {
                    errorMessage = "Student personal details not found.";
                }
            } catch (Exception e) {
                errorMessage = "Database Error: " + e.getMessage();
            } finally {
                if (rs != null) try { rs.close(); } catch (SQLException e) { /* ignored */ }
                if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
                if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
            }

            if (errorMessage != null) {
        %>
            <div class="form-container text-center" style="margin-top: 20px;">
                <h3 style="color: red;">Error:</h3>
                <p><%= errorMessage %></p>
            </div>
        <%
            }
        %>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</html>



