<%@ page import="java.sql.*" %>
<%@ include file="auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    String studentIdStr = request.getParameter("id");
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="home.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages.jsp" class="active">Home</a></li>
            <li><a href="pending_fee.jsp">Pending Fee</a></li>
            <li><a href="profile.jsp">My Enrollments</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% 
            try {
                int studentId = Integer.parseInt(studentIdStr);
                Class.forName(DB_DRIVER);
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                pstmt = conn.prepareStatement("SELECT * FROM studentMaster WHERE id = ?");
                pstmt.setInt(1, studentId);
                rs = pstmt.executeQuery();

                if (rs.next()) {
        %>
                    <div class="form-container">
                        <h2 class="text-center">Modify Your Details</h2>
                        <form method="post" action="editstudentprofile_1.jsp">
                            <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" value="<%= rs.getString("name") %>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password">
                                <span id="newPasswordError" style="color: red; font-size: 0.8em;"></span>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password">
                                <span id="confirmPasswordError" style="color: red; font-size: 0.8em;"></span>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<%= rs.getString("email") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="mobile">Mobile</label>
                                <input type="text" id="mobile" name="mobile" value="<%= rs.getString("mobile") %>" required pattern="[0-9]{10}" title="Please enter a 10 digit mobile number." maxlength="10">
                            </div>
                            <div class="form-group">
                                <label for="city">Address</label>
                                <input type="text" id="city" name="city" value="<%= rs.getString("city") %>" required>
                            </div>
                            <div class="form-group text-center">
                                <input type="submit" value="UPDATE PROFILE" class="btn">
                            </div>
                        </form>
                    </div>
        <%
                } else {
                    out.println("<p class='text-center' style='color:red;'>Student not found.</p>");
                }
            } catch (Exception e) {
                out.println("<p class='text-center' style='color:red;'>Error fetching student details: " + e.getMessage() + "</p>");
            } finally {
                closeQuietly(rs);
                closeQuietly(pstmt);
                closeQuietly(conn);
            }
        %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click
        const studentForm = document.querySelector('.form-container form');
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');
        const newPasswordError = document.getElementById('newPasswordError');
        const confirmPasswordError = document.getElementById('confirmPasswordError');

        function validateNewPassword() {
            const newPass = newPassword.value;
            const confirmPass = confirmPassword.value;
            newPasswordError.textContent = ""; // Clear previous errors

            if (newPass === '' && confirmPass === '') {
                return true; // No new password is being set, valid by default
            }

            if (newPass.length < 8) {
                newPasswordError.textContent = "Password must be at least 8 characters long.";
                return false;
            }
            if (!/[A-Z]/.test(newPass)) {
                newPasswordError.textContent = "Password must contain at least one uppercase letter.";
                return false;
            }
            if (!/[a-z]/.test(newPass)) {
                newPasswordError.textContent = "Password must contain at least one lowercase letter.";
                return false;
            }
            if (!/[0-9]/.test(newPass)) {
                newPasswordError.textContent = "Password must contain at least one number.";
                return false;
            }
            if (!/[^a-zA-Z0-9]/.test(newPass)) {
                newPasswordError.textContent = "Password must contain at least one special character.";
                return false;
            }

            return true; // All validations passed
        }

        function validateConfirmPassword() {
            const newPass = newPassword.value;
            const confirmPass = confirmPassword.value;
            confirmPasswordError.textContent = ""; // Clear previous errors

            if (newPass !== confirmPass) {
                confirmPasswordError.textContent = "New passwords do not match.";
                return false;
            }

            return true;
        }
        
        if(newPassword) {
            newPassword.addEventListener('input', validateNewPassword);
        }
        
        if(confirmPassword) {
            confirmPassword.addEventListener('input', validateConfirmPassword);
        }

        if (studentForm) {
            studentForm.addEventListener('submit', function(event) {
                if (!validateNewPassword() || !validateConfirmPassword()) {
                    event.preventDefault();
                }
            });
        }

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</body>
</html>