<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // Input parameters
    String name = request.getParameter("name");
    String passord = request.getParameter("passord");
    String email = request.getParameter("email");
    String mobile = request.getParameter("mobile");
    String city = request.getParameter("city");

    // State variables
    String errorMessage = null;
    boolean success = false;

    // Resource declarations
    Connection conn = null;
    PreparedStatement checkPstmt = null;
    PreparedStatement insertPstmt = null;
    ResultSet rs = null;

    // Validate input
    if (name == null || name.trim().isEmpty() ||
        passord == null || passord.trim().isEmpty() ||
        email == null || email.trim().isEmpty() ||
        mobile == null || mobile.trim().isEmpty() ||
        city == null || city.trim().isEmpty()) {
        errorMessage = "All fields are required. Please fill out the form completely and try again.";
    } else if (!mobile.matches("\\d{10}")) {
        errorMessage = "Please enter a 10 digit mobile number.";
    } else {
        try {
            // Establish connection
            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Check for duplicate student name
            String checkQuery = "SELECT COUNT(*) FROM studentMaster WHERE Name = ?";
            checkPstmt = conn.prepareStatement(checkQuery);
            checkPstmt.setString(1, name);
            rs = checkPstmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                errorMessage = "A student with the name '" + name + "' already exists. Please choose a different name.";
            } else {
                // Insert new student
                String insertQuery = "INSERT INTO studentMaster(Name, passord, email, mobile, city) VALUES (?, ?, ?, ?, ?)";
                insertPstmt = conn.prepareStatement(insertQuery);
                insertPstmt.setString(1, name);
                insertPstmt.setString(2, passord);
                insertPstmt.setString(3, email);
                insertPstmt.setString(4, mobile);
                insertPstmt.setString(5, city);

                if (insertPstmt.executeUpdate() > 0) {
                    response.sendRedirect("viewallstudent.jsp?status=success");
                    return; // Stop further execution of this JSP
                } else {
                    errorMessage = "The student could not be added due to an unexpected server error. Please try again later.";
                }
            }
        } catch (ClassNotFoundException e) {
            errorMessage = "Database driver not found. Please ensure the MySQL driver is correctly installed.";
        } catch (SQLException e) {
            errorMessage = "A database error occurred: " + e.getMessage() + ". Please check the server logs for more details.";
        } catch (Exception e) {
            errorMessage = "An unexpected error occurred: " + e.getMessage();
        } finally {
            // Clean up resources
            closeQuietly(rs);
            closeQuietly(insertPstmt);
            closeQuietly(checkPstmt);
            // Close connection only if it's not needed for the student list below
            if (!success) {
                closeQuietly(conn);
            }
        }
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <nav class="navbar">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li class="dropdown">
                <a href="#">Course</a>
                <div class="dropdown-content">
                    <a href="viewallcourse.jsp">View Course</a>
                    <a href="addcourse.jsp">Add New Course</a>
                    <a href="modifycourse.jsp">Modify Course</a>
                    <a href="deletecourse.jsp">Delete Course</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Students</a>
                <div class="dropdown-content">
                    <a href="viewallstudent.jsp">View Students</a>
                    <a href="addstudent.jsp" class="active">Add New Student</a>
                    <a href="modifystudent.jsp">Modify Student</a>
                    <a href="deletestudent.jsp">Delete Student</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% if (errorMessage != null) { %>
            <div class="form-container" style="text-align: center;">
                <h2>Error Adding Student</h2>
                <p style="color: red;"><%= errorMessage %></p>
                <a href="addstudent.jsp" class="btn">Try Again</a>
            </div>
        <% } else if (success) { %>
            <div style="text-align: center;">
                <h2>Student Added Successfully!</h2>
                <p>The new student has been successfully added to the system.</p>
                <a href="addstudent.jsp" class="btn">Add Another Student</a>
                <a href="viewallstudent.jsp" class="btn">View All Students</a>
            </div>
            <br>
            <%
                Statement stmt = null;
                ResultSet studentRs = null;
                try {
                    // Use the existing connection if it's still open
                    if (conn == null || conn.isClosed()) {
                        Class.forName(DB_DRIVER);
                        conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    }
                    stmt = conn.createStatement();
                    studentRs = stmt.executeQuery("SELECT * FROM studentMaster ORDER BY id DESC");
            %>
                <h3 class="text-center">Current Student List</h3>
                <table class="content-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>City</th>
                        </tr>
                    </thead>
                    <tbody>
            <%      while(studentRs.next()) { %>
                        <tr>
                            <td><%= studentRs.getInt("Id") %></td>
                            <td><%= studentRs.getString("Name") %></td>
                            <td><%= studentRs.getString("email") %></td>
                            <td><%= studentRs.getString("mobile") %></td>
                            <td><%= studentRs.getString("city") %></td>
                        </tr>
            <%      } %>
                    </tbody>
                </table>
            <%
                } catch (Exception e) {
            %>
                <div style="text-align: center;">
                    <p style="color: orange;">Could not display the student list: <%= e.getMessage() %></p>
                </div>
            <%
                } finally {
                    // Clean up resources for the student list
                    closeQuietly(studentRs);
                    closeQuietly(stmt);
                    closeQuietly(conn); // Close the connection here
                }
            } %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>

