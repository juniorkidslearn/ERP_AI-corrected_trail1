<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.*" %>
<%
    Connection conn = null;
    PreparedStatement adminPstmt = null;
    ResultSet adminRs = null;
    PreparedStatement studentPstmt = null;
    ResultSet rs = null;
    String errorMessage = "Invalid username or password."; // Default error message
    boolean loggedIn = false;

    String name = request.getParameter("name");
    String pwd = request.getParameter("password");

    if (name == null || name.trim().isEmpty() || pwd == null || pwd.trim().isEmpty()) {
        errorMessage = "Username and password cannot be empty.";
    } else {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");
            
            // --- Admin Check ---
            String adminQuery = "SELECT ID FROM adminMaster WHERE Name = ? AND passord = ?";
            adminPstmt = conn.prepareStatement(adminQuery);
            adminPstmt.setString(1, name);
            adminPstmt.setString(2, pwd);
            adminRs = adminPstmt.executeQuery();

            if (adminRs.next()) {
                session.setAttribute("admin_id", adminRs.getInt("ID"));
                session.setAttribute("username", name);
                response.sendRedirect("DisplayMessages_1.jsp");
                loggedIn = true;
            } else {
                // --- Student Check ---
                String studentQuery = "SELECT * FROM studentMaster WHERE name = ? AND passord = ?";
                studentPstmt = conn.prepareStatement(studentQuery);
                studentPstmt.setString(1, name);
                studentPstmt.setString(2, pwd);
                rs = studentPstmt.executeQuery();

                if (rs.next()) {
                    session.setAttribute("username", name);
                    response.sendRedirect("DisplayMessages.jsp");
                    loggedIn = true;
                }
            }
        } catch (Exception e) {
            errorMessage = "An error occurred during login: " + e.getMessage();
            // It's good practice to log the full stack trace for debugging purposes
            e.printStackTrace(); 
        } finally {
            // Close resources in reverse order of creation to avoid issues
            if (rs != null) { try { rs.close(); } catch (SQLException e) { /* ignored */ } }
            if (studentPstmt != null) { try { studentPstmt.close(); } catch (SQLException e) { /* ignored */ } }
            if (adminRs != null) { try { adminRs.close(); } catch (SQLException e) { /* ignored */ } }
            if (adminPstmt != null) { try { adminPstmt.close(); } catch (SQLException e) { /* ignored */ } }
            if (conn != null) { try { conn.close(); } catch (SQLException e) { /* ignored */ } }
        }
    }
    
    // If not logged in and not redirected, show the error page
    if (!loggedIn) {
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System - Login Failed</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7f6;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;">
    <div class="container">
        <div class="form-container text-center">
            <h2>Login Failed</h2>
            <p style="color: red;"><%= errorMessage %></p>
            <a href="home.jsp" class="btn btn-danger">Try Again</a>
        </div>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links'); // This might not exist in LoginForm_1.jsp

        if (menuToggle) { // Only check for menuToggle as navLinks might not be present in this specific navbar
            menuToggle.addEventListener('click', function () {
                // If navLinks exists, toggle it
                if (navLinks) {
                    navLinks.classList.toggle('active');
                }
                menuToggle.classList.toggle('active');
            });
        }
    });
</script>
</html>
<%
    }
%>

