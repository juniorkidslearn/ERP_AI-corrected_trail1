<%@ page import="java.sql.*, java.util.*, java.net.URLEncoder, java.text.SimpleDateFormat, java.util.Date, java.util.Locale" %>
<%@ include file="admin_auth.jsp" %>
<%
    // --- SERVER-SIDE LOGIC ---
    Connection conn = null;
    Statement st = null;
    ResultSet rs = null;
    ResultSet rsClasses = null;
    Map<String, List<Map<String, Object>>> studentEnrollments = new LinkedHashMap<String, List<Map<String, Object>>>();
    List<String> classes = new ArrayList<String>();
    String errorMessage = "";
 
    // Get filter parameters from request
    String studentIdStr = request.getParameter("selectedEmployee");
    String feeStatus = request.getParameter("fee_status") != null ? request.getParameter("fee_status") : "all";
    String[] selectedClasses = request.getParameterValues("class");
    String colorFilter = request.getParameter("color_filter") != null ? request.getParameter("color_filter") : "all";
    boolean isAjax = "true".equals(request.getParameter("is_ajax"));

    try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");
        st = conn.createStatement();

        // Get all unique class names for the filter dropdown (only on full page load)
        if (!isAjax) {
            rsClasses = st.executeQuery("SELECT DISTINCT Nam FROM CourseMaster ORDER BY CASE Nam WHEN 'Playgroup' THEN 0 WHEN 'Nursery' THEN 1 WHEN 'LKG' THEN 2 WHEN 'UKG' THEN 3 WHEN 'Class I' THEN 4 WHEN 'Class II' THEN 5 WHEN 'Class III' THEN 6 WHEN 'Class IV' THEN 7 WHEN 'Class V' THEN 8 WHEN 'Class VI' THEN 9 WHEN 'Class VII' THEN 10 WHEN 'Class VIII' THEN 11 WHEN 'Class IX' THEN 12 WHEN 'Class X' THEN 13 WHEN 'Class XI' THEN 14 WHEN 'Class XII' THEN 15 ELSE 16 END");
            while (rsClasses.next()) {
                classes.add(rsClasses.getString("Nam"));
            }
        }

        // Base query
        StringBuilder queryBuilder = new StringBuilder(
            "SELECT s.name AS studentName, s.email AS studentEmail, s.mobile AS studentMobile, " +
            "cm.Nam AS courseName, cm.DURATION AS courseDuration, cm.technology AS courseTechnology, " +
            "cm.fees AS totalFee, IFNULL(fp.amount, 0) AS feePaid " +
            "FROM studentMaster s " +
            "JOIN CoursesEnrolled ce ON s.id = ce.studentid " +
            "JOIN CourseMaster cm ON ce.courseid = cm.id " +
            "LEFT JOIN feepaid fp ON ce.eid = fp.id "
        );

        List<String> whereClauses = new ArrayList<String>();
        if (studentIdStr != null && !studentIdStr.isEmpty()) {
            whereClauses.add("s.id = " + studentIdStr);
        }
        if (selectedClasses != null && selectedClasses.length > 0) {
            StringBuilder inClause = new StringBuilder();
            for (int i = 0; i < selectedClasses.length; i++) {
                inClause.append("'").append(selectedClasses[i].replace("'", "''")).append("'");
                if (i < selectedClasses.length - 1) {
                    inClause.append(",");
                }
            }
            whereClauses.add("cm.Nam IN (" + inClause.toString() + ")");
        }
        if (!whereClauses.isEmpty()) {
            queryBuilder.append(" WHERE ").append(String.join(" AND ", whereClauses));
        }

        String havingClause = "";
        if ("gt_zero".equals(feeStatus)) {
            havingClause = " HAVING (totalFee - feePaid) > 0";
        } else if ("eq_zero".equals(feeStatus)) {
            havingClause = " HAVING (totalFee - feePaid) = 0";
        } else if ("lt_zero".equals(feeStatus)) {
            havingClause = " HAVING (totalFee - feePaid) < 0";
        }
        queryBuilder.append(havingClause);
        
        queryBuilder.append(" ORDER BY s.name, CASE cm.Nam " +
            "WHEN 'Playgroup' THEN 0 WHEN 'Nursery' THEN 1 WHEN 'LKG' THEN 2 WHEN 'UKG' THEN 3 " +
            "WHEN 'Class I' THEN 4 WHEN 'Class II' THEN 5 WHEN 'Class III' THEN 6 WHEN 'Class IV' THEN 7 " +
            "WHEN 'Class V' THEN 8 WHEN 'Class VI' THEN 9 WHEN 'Class VII' THEN 10 WHEN 'Class VIII' THEN 11 " +
            "WHEN 'Class IX' THEN 12 WHEN 'Class X' THEN 13 WHEN 'Class XI' THEN 14 WHEN 'Class XII' THEN 15 " +
            "ELSE 16 END DESC");

        rs = st.executeQuery(queryBuilder.toString());

        while (rs.next()) {
            String studentName = rs.getString("studentName");
            Map<String, Object> rowData = new HashMap<String, Object>();
            rowData.put("studentName", rs.getString("studentName"));
            rowData.put("studentEmail", rs.getString("studentEmail"));
            rowData.put("studentMobile", rs.getString("studentMobile"));
            rowData.put("courseName", rs.getString("courseName"));
            rowData.put("courseDuration", rs.getInt("courseDuration"));
            rowData.put("courseTechnology", rs.getString("courseTechnology"));
            rowData.put("totalFee", rs.getInt("totalFee"));
            rowData.put("feePaid", rs.getInt("feePaid"));
            
            List<Map<String, Object>> enrollments = studentEnrollments.get(studentName);
            if (enrollments == null) {
                enrollments = new ArrayList<Map<String, Object>>();
                studentEnrollments.put(studentName, enrollments);
            }
            enrollments.add(rowData);
        }
    } catch (Exception e) {
        errorMessage = "Database Error: " + e.getMessage();
    } finally {
        if (rs != null) try { rs.close(); } catch (SQLException e) {}
        if (rsClasses != null) try { rsClasses.close(); } catch (SQLException e) {}
        if (st != null) try { st.close(); } catch (SQLException e) {}
        if (conn != null) try { conn.close(); } catch (SQLException e) {}
    }

    double totalPendingAmount = 0;
    for (List<Map<String, Object>> enrollments : studentEnrollments.values()) {
        for (Map<String, Object> rowData : enrollments) {
            int totalFee = (Integer) rowData.get("totalFee");
            int feePaid = (Integer) rowData.get("feePaid");
            totalPendingAmount += (totalFee - feePaid);
        }
    }

    // --- RENDER VIEW ---
    if (!isAjax) { // Render full page on initial load
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Enrollment Details | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <style>
        .filter-bar {
            background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;
            border: 1px solid #dee2e6; display: flex; flex-wrap: wrap; align-items: center; gap: 15px;
        }
        .filter-bar .form-control {
            border-radius: 6px; border: 1px solid #ced4da; padding: 8px 12px;
            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
            height: 40px; flex-grow: 1; min-width: 150px;
        }
        .filter-bar .choices__inner {
            border-radius: 6px; min-height: 40px;
        }
        .filter-bar .form-control:focus {
            border-color: #80bdff; outline: 0; box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
        .btn-reset {
            background-color: #28a745; border-color: #28a745; color: #fff; text-decoration: none;
            padding: 8px 16px; border-radius: 6px; display: inline-flex; align-items: flex-end;
            justify-content: center; text-align: center; cursor: pointer; user-select: none;
            height: 40px; transition: background-color .15s ease-in-out, border-color .15s ease-in-out;
        }
        .btn-reset:hover { background-color: #218838; border-color: #1e7e34; color: #fff; }
    </style>
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu"><span></span><span></span><span></span></button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown"><a href="#">Enrol</a><div class="dropdown-content"><a href="enrol.jsp">Enrol</a><a href="removestudent.jsp">Remove</a></div></li>
            <li><a href="view_enrollments.jsp" class="active">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <h2 class="text-center">All Student Enrollment Details</h2>
        <div class="download-buttons-wrapper" style="margin-bottom: 15px;">
            <div class="download-buttons">
                <button onclick="downloadPdf()" class="btn">Download PDF</button>
                <%
                    SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss", Locale.ENGLISH);
                    String timestamp = sdf.format(new Date());
                    String downloadFilename = "Admin_" + timestamp + ".csv";

                    String downloadQueryString = "format=csv" +
                        "&selectedEmployee=" + (studentIdStr != null ? URLEncoder.encode(studentIdStr, "UTF-8") : "") +
                        "&fee_status=" + feeStatus;
                    
                    if (selectedClasses != null && selectedClasses.length > 0) {
                        for (String cls : selectedClasses) {
                            downloadQueryString += "&class=" + URLEncoder.encode(cls, "UTF-8");
                        }
                    }
                    downloadQueryString += "&color_filter=" + colorFilter;
                    downloadQueryString += "&filename=" + URLEncoder.encode(downloadFilename, "UTF-8");
                %>
                <a id="download-csv-link" href="download_all_enrollments.jsp?<%= downloadQueryString %>" class="btn" download="<%= downloadFilename %>">Download CSV</a>
            </div>
        </div>

        <div class="filter-bar" style="flex-direction: column; align-items: stretch;">
            <form action="view_enrollments.jsp" method="GET" id="filterForm" style="width: 100%;">
                <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 15px; width: 100%;">
                    <div class="form-group" style="flex-grow: 2; min-width: 200px; margin-bottom: 0;">
                        <label for="selectedEmployee" style="font-weight: bold; margin-bottom: 5px; display: block;">Select a Student:</label>
                        <select name="selectedEmployee" id="selectedEmployee" class="form-control">
                            <option value="">-- Select Student --</option>
                            <%
                                Connection studentConn = null;
                                Statement studentSt = null;
                                ResultSet studentRs = null;
                                try {
                                    studentConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");
                                    studentSt = studentConn.createStatement();
                                    studentRs = studentSt.executeQuery("SELECT * FROM studentMaster ORDER BY Name");
                                    String currentStudentId = request.getParameter("selectedEmployee");
                                    while (studentRs.next()) {
                                        String id = studentRs.getString("ID");
                                        String name = studentRs.getString("Name");
                                        String mobile = studentRs.getString("mobile");
                                        String email = studentRs.getString("email");
                                        String city = studentRs.getString("city");
                                        String selected = (currentStudentId != null && currentStudentId.equals(id)) ? "selected" : "";
                                        out.println("<option value='" + id + "' " + selected + ">" + name + ", " + mobile + ", " + email + ", " + city + "</option>");
                                    }
                                } catch (Exception e) {
                                    // Error handling
                                } finally {
                                    if (studentRs != null) try { studentRs.close(); } catch (SQLException e) {}
                                    if (studentSt != null) try { studentSt.close(); } catch (SQLException e) {}
                                    if (studentConn != null) try { studentConn.close(); } catch (SQLException e) {}
                                }
                            %>
                        </select>
                    </div>

                    <div class="form-group" style="flex-grow: 1; min-width: 150px; margin-bottom: 0;">
                        <label for="colorFilter" style="font-weight: bold; margin-bottom: 5px; display: block;">Color Filter:</label>
                        <select name="color_filter" id="colorFilter" class="form-control">
                            <option value="all" <%= "all".equals(colorFilter) ? "selected" : "" %>>All Colors</option>
                            <option value="white" <%= "white".equals(colorFilter) ? "selected" : "" %>>White Color Only</option>
                        </select>
                    </div>
                    <div class="form-group" style="flex-grow: 1; min-width: 150px; margin-bottom: 0;">
                        <label for="feeStatus" style="font-weight: bold; margin-bottom: 5px; display: block;">Fee Status:</label>
                        <select name="fee_status" id="feeStatus" class="form-control">
                            <option value="all" <%= "all".equals(feeStatus) ? "selected" : "" %>>All Fee Status</option>
                            <option value="gt_zero" <%= "gt_zero".equals(feeStatus) ? "selected" : "" %>>Fee remaining: > 0</option>
                            <option value="eq_zero" <%= "eq_zero".equals(feeStatus) ? "selected" : "" %>>Fee remaining: = 0</option>
                            <option value="lt_zero" <%= "lt_zero".equals(feeStatus) ? "selected" : "" %>>Fee remaining: < 0</option>
                        </select>
                    </div>
                     <a href="view_enrollments.jsp" class="btn-reset" style="align-self: flex-end;">Reset</a>
                </div>
                
                <div style="margin-top: 15px;">
                    <label style="font-weight: bold; margin-bottom: 5px; display: block;">Filter by Class:</label>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px; padding: 10px; border: 1px solid #ced4da; border-radius: 6px;">
                        <% 
                        Set<String> selectedClassesSet = selectedClasses != null ? new HashSet<String>(Arrays.asList(selectedClasses)) : new HashSet<String>();
                        for (String className : classes) { 
                        %>
                            <label>
                                <input type="checkbox" class="class-filter-checkbox" name="class" value="<%= className %>" <%= selectedClassesSet.contains(className) ? "checked" : "" %>> <%= className %>
                            </label>
                        <% } %>
                    </div>
                </div>
            </form>
        </div>

        <div class="total-pending-amount" style="margin-bottom: 20px; text-align: right; font-size: 1.2em; font-weight: bold;">
            Total pending amount to Pay: <span id="total-pending-amount-value">Rs <%= String.format("%.2f", totalPendingAmount) %></span>
        </div>

        <table class="content-table" id="enrollments-table">
            <thead>
                <tr>
                    <th>Student Name</th><th>Class</th><th>Duration</th><th>Email</th><th>Phone Number</th><th>Subject</th><th>Total Fee</th><th>Fee Paid</th><th>Fee Remaining</th>
                </tr>
            </thead>
            <tbody id="enrollments-table-body">
<% } // End of initial page render block %>
<%-- This part renders the table rows for BOTH initial load and AJAX requests --%>
<%
    if (!errorMessage.isEmpty()) {
        out.println("<tr><td colspan='9' style='text-align:center; color:red;'>" + errorMessage + "</td></tr>");
    } else if (studentEnrollments.isEmpty()) {
        out.println("<tr><td colspan='9' style='text-align:center;'>No enrollment details found for the selected filters.</td></tr>");
    } else {
        Random rand = new Random();
        for (Map.Entry<String, List<Map<String, Object>>> entry : studentEnrollments.entrySet()) {
            List<Map<String, Object>> enrollments = entry.getValue();
            String highestClass = enrollments.get(0).get("courseName").toString();

            rand.setSeed(entry.getKey().hashCode());
            String studentColor = "rgb(" + (rand.nextInt(128) + 128) + "," + (rand.nextInt(128) + 128) + "," + (rand.nextInt(128) + 128) + ")";

            if ("white".equals(colorFilter)) {
                Map<String, Object> rowData = enrollments.get(0);
                int totalFee = (Integer) rowData.get("totalFee");
                int feePaid = (Integer) rowData.get("feePaid");
%>
                <tr>
                    <td><%= rowData.get("studentName") %></td><td><%= rowData.get("courseName") %></td>
                    <td><%= rowData.get("courseDuration") %> months</td><td><%= rowData.get("studentEmail") %></td>
                    <td><%= rowData.get("studentMobile") %></td><td><%= rowData.get("courseTechnology") %></td>
                    <td>Rs <%= totalFee %></td><td>Rs <%= feePaid %></td><td>Rs <%= totalFee - feePaid %></td>
                </tr>
<%
                continue;
            }

            for (Map<String, Object> rowData : enrollments) {
                String style = "";
                if (enrollments.size() > 1 && !rowData.get("courseName").equals(highestClass)) {
                    style = "style='background-color:" + studentColor + ";'";
                }
                int totalFee = (Integer) rowData.get("totalFee");
                int feePaid = (Integer) rowData.get("feePaid");
%>
                <tr <%= style %>>
                    <td><%= rowData.get("studentName") %></td><td><%= rowData.get("courseName") %></td>
                    <td><%= rowData.get("courseDuration") %> months</td><td><%= rowData.get("studentEmail") %></td>
                    <td><%= rowData.get("studentMobile") %></td><td><%= rowData.get("courseTechnology") %></td>
                    <td>Rs <%= totalFee %></td><td>Rs <%= feePaid %></td><td>Rs <%= totalFee - feePaid %></td>
                </tr>
<%
            }
        }
    }
%>
<% if (!isAjax) { // Render the rest of the page only on initial load %>
            </tbody>
        </table>
    </div>
    <script>
        function downloadPdf() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'mm', 'a4');
            const pageWidth = doc.internal.pageSize.getWidth();

            doc.setFontSize(18);
            doc.text("Filtered Student Enrollment Details", 14, 22);

            const today = new Date();
            const dateOptions = { day: '2-digit', month: 'long', year: 'numeric' };
            const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
            const dateStr = "Date: " + today.toLocaleDateString('en-GB', dateOptions) + " (" + today.toLocaleTimeString('en-GB', timeOptions) + ")";
            doc.setFontSize(10);
            doc.setTextColor(100);
            doc.text(dateStr, pageWidth - 14, 22, { align: 'right' });

            let currentY = 30; // Starting Y position for filter info

            // Get current filter values
            const studentSelect = document.getElementById('selectedEmployee');
            const studentVal = studentSelect.options[studentSelect.selectedIndex].text;
            const colorFilterVal = document.getElementById('colorFilter').value;
            const feeStatusVal = document.getElementById('feeStatus').value;
            const selectedClassesCheckboxes = document.querySelectorAll('.class-filter-checkbox:checked');

            let studentText = "Student Description: All";
            if(studentSelect.value) {
                studentText = "Student Description: " + studentVal;
            }
            
            let colorFilterText;
            switch (colorFilterVal) {
                case 'all':
                    colorFilterText = "Color Filter: Not applied filter [Note : Not applied filter means all classes for student]";
                    break;
                case 'white':
                    colorFilterText = "Color Filter: White Color Only [Note : White colour only filter means current class for student]";
                    break;
                default:
                    colorFilterText = `Color Filter: ${colorFilterVal}`;
            }

            let feeStatusText;
            switch (feeStatusVal) {
                case 'all':
                    feeStatusText = "Fee status: Not applied filter";
                    break;
                case 'gt_zero':
                    feeStatusText = "Fee status: Fee remaining > 0 [Note: Fee remaining > 0 filter means all students which have pending amount]";
                    break;
                case 'eq_zero':
                    feeStatusText = "Fee status: Fee remaining = 0 [Note: Fee remaining = 0 filter means all students which have no pending amount]";
                    break;
                case 'lt_zero':
                    feeStatusText = "Fee status: Fee remaining < 0 [Note: Fee remaining < 0 filter  means all students which have paid pending amount and join higher class and teacher increase the fee for previous class then Fee remaining will be negative, here teacher have to add amount to make zero because student is already paid in previous class]";
                    break;
                default:
                    feeStatusText = `Fee status: ${feeStatusVal}`;
            }

            let classesFilterText = "Classes: All";
            if (selectedClassesCheckboxes.length > 0) {
                const classesNames = Array.from(selectedClassesCheckboxes).map(cb => cb.value);
                classesFilterText = "Classes: " + classesNames.join(", ");
            }

            // Add filter information to PDF
            doc.setFontSize(10);
            doc.setTextColor(0); // Black color for filter text
            const textOptions = { maxWidth: pageWidth - 28 };
            
            currentY += 5;
            doc.text(studentText, 14, currentY, textOptions);
            currentY += doc.getTextDimensions(studentText, textOptions).h + 2;

            doc.text(classesFilterText, 14, currentY, textOptions);
            currentY += doc.getTextDimensions(classesFilterText, textOptions).h + 2;
            
            doc.text(colorFilterText, 14, currentY, textOptions);
            currentY += doc.getTextDimensions(colorFilterText, textOptions).h + 2;

            doc.text(feeStatusText, 14, currentY, textOptions);
            currentY += doc.getTextDimensions(feeStatusText, textOptions).h + 2;

            currentY += 4; // Add some extra space before the table

            doc.autoTable({
                html: '#enrollments-table',
                startY: currentY, // Adjusted startY for the table
                theme: 'grid',
                headStyles: { fillColor: [22, 160, 133] },
            });

            const finalY = doc.autoTable.previous.finalY;
            const totalAmountEl = document.getElementById('total-pending-amount-value');
            if (totalAmountEl) {
                const totalAmountText = 'Total pending amount to Pay: ' + totalAmountEl.innerText;
                doc.setFontSize(12);
                doc.setFont('helvetica', 'bold');
                doc.text(totalAmountText, 14, finalY + 15);
            }

            // Add Signature of admin
            doc.setFontSize(10); // Smaller font for signature
            doc.setFont('helvetica', 'bold'); // Make it bold
            doc.text("Signature of admin with date", 30, doc.internal.pageSize.getHeight() - 20); // 30mm from left, 20mm from bottom

            const date = new Date();
            const day = date.getDate();
            const month = date.getMonth() + 1;
            const year = date.getFullYear();
            const hours = date.getHours();
            const minutes = date.getMinutes();
            const seconds = date.getSeconds();
            const pdfFilename = "Admin_" + day + "_" + month + "_" + year + "_" + hours + "_" + minutes + "_" + seconds + ".pdf";
            doc.save(pdfFilename);
        }

        // --- CLIENT-SIDE SCRIPTING ---
        document.addEventListener('DOMContentLoaded', function () {
            
            // --- ELEMENT REFERENCES ---
            const studentSelect = document.getElementById('selectedEmployee');
            const colorFilter = document.getElementById('colorFilter');
            const feeStatus = document.getElementById('feeStatus');
            const tableBody = document.getElementById('enrollments-table-body');
            const csvLink = document.getElementById('download-csv-link');
            const classCheckboxes = document.querySelectorAll('.class-filter-checkbox');

            if(studentSelect) {
                const choices = new Choices(studentSelect, {
                    searchEnabled: true,
                    itemSelectText: 'Press to select',
                });
            }

            // --- CORE AJAX FUNCTION ---
            async function updateTable() {
                const params = new URLSearchParams();
                if(studentSelect && studentSelect.value) params.append('selectedEmployee', studentSelect.value);
                if(colorFilter) params.append('color_filter', colorFilter.value);
                if(feeStatus) params.append('fee_status', feeStatus.value);
                
                const selectedClasses = document.querySelectorAll('.class-filter-checkbox:checked');
                selectedClasses.forEach(checkbox => {
                    params.append('class', checkbox.value);
                });
                
                // Update Download link URL
                const downloadParams = new URLSearchParams(params);
                if(csvLink) {
                    const date = new Date();
                    const day = date.getDate();
                    const month = date.getMonth() + 1; // Use number for now
                    const year = date.getFullYear();
                    const hours = date.getHours();
                    const minutes = date.getMinutes();
                    const seconds = date.getSeconds();
                    const csvFilename = "Admin_" + day + "_" + month + "_" + year + "_" + hours + "_" + minutes + "_" + seconds + ".csv";
                    
                    downloadParams.append('filename', csvFilename);
                    csvLink.href = 'download_all_enrollments.jsp?' + downloadParams.toString();
                    csvLink.download = csvFilename;
                }

                // Fetch and update table body
                params.append('is_ajax', 'true');
                try {
                    tableBody.innerHTML = "<tr><td colspan='9' style='text-align:center;'>Loading...</td></tr>";
                    const response = await fetch('view_enrollments.jsp?' + params.toString());
                    const newBodyHtml = await response.text();
                    if(tableBody) tableBody.innerHTML = newBodyHtml;

                    // Recalculate total on client side
                    let total = 0;
                    const rows = tableBody.querySelectorAll('tr');
                    rows.forEach(row => {
                        // Make sure it's a data row, not a message row
                        if (row.cells.length === 9) {
                            const feeRemainingCell = row.cells[8]; // 9th cell is "Fee Remaining"
                            if (feeRemainingCell) {
                                // Extract number from "Rs XXX"
                                const text = feeRemainingCell.innerText.replace(/Rs\s*/, '').trim();
                                const value = parseFloat(text);
                                if (!isNaN(value)) {
                                    total += value;
                                }
                            }
                        }
                    });

                    const totalElement = document.getElementById('total-pending-amount-value');
                    if (totalElement) {
                        totalElement.innerText = 'Rs ' + total.toFixed(2);
                    }
                } catch (error) {
                    if(tableBody) tableBody.innerHTML = "<tr><td colspan='9' style='color:red; text-align:center;'>Error loading data.</td></tr>";
                    console.error('Error fetching table data:', error);
                }
            }

            // --- EVENT LISTENERS ---
            if(studentSelect) studentSelect.addEventListener('change', updateTable);
            if(colorFilter) colorFilter.addEventListener('change', updateTable);
            if(feeStatus) feeStatus.addEventListener('change', updateTable);

            classCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateTable);
            });
            
            // --- NAVBAR LOGIC ---
            const menuToggle = document.querySelector('.menu-toggle');
            const navLinks = document.querySelector('.nav-links');
            const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a');
            const navbar = document.querySelector('.navbar');

            if (menuToggle && navLinks) {
                menuToggle.addEventListener('click', function () {
                    navLinks.classList.toggle('active');
                    menuToggle.classList.toggle('active');
                });

                navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                    link.addEventListener('click', () => {
                        navLinks.classList.remove('active');
                        menuToggle.classList.remove('active');
                        dropdownToggles.forEach(toggle => {
                            const parentDropdown = toggle.closest('.dropdown');
                            if (parentDropdown) parentDropdown.classList.remove('active');
                        });
                    });
                });
            }

            dropdownToggles.forEach(toggle => {
                toggle.addEventListener('click', function (event) {
                    if (navLinks && navLinks.classList.contains('active')) {
                        event.preventDefault();
                        const parentDropdown = this.closest('.dropdown');
                        if (parentDropdown) {
                            dropdownToggles.forEach(otherToggle => {
                                const otherParentDropdown = otherToggle.closest('.dropdown');
                                if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                    otherParentDropdown.classList.remove('active');
                                }
                            });
                            parentDropdown.classList.toggle('active');
                        }
                    }
                });
            });

             if (menuToggle && navLinks) {
                menuToggle.addEventListener('click', function () {
                    if (!navLinks.classList.contains('active')) {
                        dropdownToggles.forEach(toggle => {
                            const parentDropdown = toggle.closest('.dropdown');
                            if (parentDropdown) parentDropdown.classList.remove('active');
                        });
                    }
                });
            }

            document.addEventListener('click', function (event) {
                if (navLinks && navLinks.classList.contains('active')) {
                    if (navbar && !navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                        navLinks.classList.remove('active');
                        menuToggle.classList.remove('active');
                        dropdownToggles.forEach(toggle => {
                            const parentDropdown = toggle.closest('.dropdown');
                            if (parentDropdown) parentDropdown.classList.remove('active');
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>
<% } // End of full page render block %>