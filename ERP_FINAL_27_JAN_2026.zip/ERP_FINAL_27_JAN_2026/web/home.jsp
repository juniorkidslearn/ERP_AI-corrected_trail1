<%-- 
    Document   : LoginForm
    Created on : Dec 15, 2018, 10:49:01 AM
    Author     : HP
--%><title>Juniorkidslearn's Enrollment System</title>
<head>
    <title>Juniorkidslearn's Enrollment System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="home.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="home.jsp" class="active">Home</a></li>
        </ul>
    </nav>

    <div class="container">
        <% 
           String user = (String)session.getAttribute("username");
           if(user == null){
        %>
        <div class="form-container">
            <h2>Login</h2>
            <form method="post" action="LoginForm_1.jsp">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group text-center">
                    <input type="submit" value="LOGIN" class="btn">
                </div>

                <p class="text-center"><a href="forgot_password.jsp">Forgot Password?</a></p>
            </form>
        </div>
        <%
          } else {
              response.sendRedirect("DisplayMessages.jsp");
          }
        %>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</html>