<%@ page import="java.sql.*, java.util.*" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    String studentIdStr = request.getParameter("selectedEmployee");
    String searchParam = request.getParameter("search"); // This will be null for fee_1.jsp now
    String[] selectedClassesParams = request.getParameterValues("class");

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    if (studentIdStr != null && !studentIdStr.isEmpty()) {
        try {
            int studentId = Integer.parseInt(studentIdStr);
            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String query = "SELECT cm.Nam, cm.fees, cm.DURATION AS courseDuration, fp.amount, ce.eid FROM CourseMaster cm " +
                           "JOIN CoursesEnrolled ce ON cm.id = ce.courseid " +
                           "JOIN feepaid fp ON ce.eid = fp.id WHERE ce.studentid = ?";
            
            StringBuilder whereClauses = new StringBuilder();
            List<Object> params = new ArrayList<>();
            params.add(studentId); 

            if (searchParam != null && !searchParam.isEmpty()) { // This block will likely not be used for fee_1.jsp
                whereClauses.append(" AND cm.Nam LIKE ?");
                params.add("%" + searchParam + "%");
            }

            if (selectedClassesParams != null && selectedClassesParams.length > 0) {
                whereClauses.append(" AND cm.Nam IN (");
                for (int i = 0; i < selectedClassesParams.length; i++) {
                    whereClauses.append("?");
                    if (i < selectedClassesParams.length - 1) {
                        whereClauses.append(",");
                    }
                    params.add(selectedClassesParams[i]);
                }
                whereClauses.append(")");
            }
            
            query += whereClauses.toString();
            pstmt = conn.prepareStatement(query);
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            rs = pstmt.executeQuery();
%>
                <table class="content-table">
                    <thead>
                        <tr>
                            <th>Course Name</th>
                            <th>Duration</th>
                            <th>Total Fee</th>
                            <th>Amount Paid</th>
                            <th>Remaining</th>
                            <th>Pay Amount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            while (rs.next()) {
                                int remaining = rs.getInt("fees") - rs.getInt("amount");
                                String formId = "form-" + rs.getInt("eid");
                        %>
                                    <tr>
                                        <td><%= rs.getString("Nam") %></td>
                                        <td><%= rs.getInt("courseDuration") %> months</td>
                                        <td>Rs <%= rs.getInt("fees") %></td>
                                        <td>Rs <%= rs.getInt("amount") %></td>
                                        <td>Rs <%= remaining %></td>
                                        <td>
                                            <input type="number" name="paymentAmount" min="0" max="<%= remaining %>" required value="0" form="<%= formId %>">
                                            <input type="hidden" name="enrollmentId" value="<%= rs.getInt("eid") %>" form="<%= formId %>">
                                        </td>
                                        <td>
                                            <form method="post" action="fee_1.jsp" id="<%= formId %>">
                                                <input type="hidden" name="selectedEmployee" value="<%= studentIdStr %>">
                                                <input type="submit" value="PAY FEES" class="btn">
                                            </form>
                                        </td>
                                    </tr>
                        <%
                                }
                            } catch (Exception e) {
                                out.println("<tr><td colspan='7'>Error fetching fee details: " + e.getMessage() + "</td></tr>");
                            } finally {
                                closeQuietly(rs);
                                closeQuietly(pstmt);
                                closeQuietly(conn);
                            }
                        %>
                    </tbody>
                </table>
<%
    } else {
        out.println("<p style='text-align:center;'>Please select a student to view fee details.</p>");
    }
%>