### Test Steps to Verify Changes

#### Test Case 1: Verify "Pending Fee" Page

1.  **Login:** Log in to the application as a student who has pending fees for multiple classes.
2.  **Navigate:** Go to the "Pending Fee" page.
3.  **Verification:**
    *   Check if the table displaying pending fees is sorted by the "Class" column in descending order based on the specified hierarchy: 'Class XII' > 'Class XI' > ... > 'Playgroup'.
    *   Ensure that all other data in the table (Duration, Subject, Total Fee, Fee Paid, Fee Remaining) is correct for each class.

#### Test Case 2: Verify "Download CSV" for Pending Fees

1.  **Login and Navigate:** Follow steps 1 and 2 from Test Case 1.
2.  **Download:** Click the "Download CSV" button.
3.  **Verification:**
    *   Open the downloaded CSV file.
    *   Verify that the data in the CSV is sorted by the "Class" column in the same descending order as on the web page.
    *   Confirm that all other columns and data are correct.

#### Test Case 3: Verify "My Enrollments" Page

1.  **Login:** Log in to the application as a student enrolled in multiple classes.
2.  **Navigate:** Go to the "My Enrollments" page.
3.  **Verification:**
    *   Check if the table displaying all enrollments is sorted by the "Class" column in descending order based on the specified hierarchy.
    *   Ensure the "Subject" for each class is displayed correctly.

#### Test Case 4: Verify "Download CSV" for All Enrollments

1.  **Login and Navigate:** Follow steps 1 and 2 from Test Case 3.
2.  **Download:** Click the "Download CSV" button.
3.  **Verification:**
    *   Open the downloaded CSV file.
    *   Verify that the data in the CSV is sorted by the "Class" column in the same descending order as on the "My Enrollments" page.
    *   Confirm that the "Subject" column is correct.

#### Test Case 5: Negative Test - No Pending Fees

1.  **Login:** Log in as a student with no pending fees.
2.  **Navigate:** Go to the "Pending Fee" page.
3.  **Verification:**
    *   The page should display a message like "No courses enrolled yet." or "No pending fees."
    *   There should be no table of fees.

#### Test Case 6: Regression Test - Other Functionality

1.  **Login and Navigate:** Log in as a student or admin and navigate through other sections of the application that are not directly related to pending fees or enrollments.
2.  **Verification:**
    *   Ensure that other functionalities (e.g., login/logout, viewing messages, admin functions) are working as expected and have not been negatively impacted by the changes.
