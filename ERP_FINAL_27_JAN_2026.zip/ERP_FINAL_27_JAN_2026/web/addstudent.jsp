<%@ include file="admin_auth.jsp" %>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="form-container">
            <h2 class="text-center">Add New Student</h2>
            <form method="post" action="addstudent_1.jsp">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="passord">Password</label>
                    <input type="password" id="passord" name="passord" required>
                    <span id="passwordError" style="color: red; font-size: 0.8em;"></span>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="number" id="mobile" name="mobile" min="0" required pattern="[0-9]{10}" title="Please enter a 10 digit mobile number." maxlength="10" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">
                    <span id="mobileError" style="color: red; font-size: 0.8em;"></span>
                </div>
                <div class="form-group">
                    <label for="city">Address</label>
                    <input type="text" id="city" name="city" required maxlength="255">
                    <span id="cityCharCount" style="font-size: 0.8em; color: gray;"></span>
                </div>
                <div class="form-group text-center">
                    <input type="submit" value="ADD STUDENT" class="btn">
                </div>
            </form>
        </div>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click
        const mobileInput = document.getElementById('mobile');
        const mobileError = document.getElementById('mobileError');
        const studentForm = document.querySelector('.form-container form'); // Assuming there's only one form
        const passwordInput = document.getElementById('passord');
        const passwordError = document.getElementById('passwordError');

        function validatePassword() {
            const pass = passwordInput.value;
            passwordError.textContent = ""; // Clear previous errors

            if (pass === '') {
                passwordError.textContent = "Password is required.";
                return false;
            }

            if (pass.length < 8) {
                passwordError.textContent = "Password must be at least 8 characters long.";
                return false;
            }
            if (!/[A-Z]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one uppercase letter.";
                return false;
            }
            if (!/[a-z]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one lowercase letter.";
                return false;
            }
            if (!/[0-9]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one number.";
                return false;
            }
            if (!/[^a-zA-Z0-9]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one special character.";
                return false;
            }

            return true; // All validations passed
        }

        if (passwordInput) {
            passwordInput.addEventListener('input', validatePassword);
        }

        function validateMobile() {
            const mobileValue = mobileInput.value;
            if (!/^\d{10}$/.test(mobileValue)) {
                mobileError.textContent = "Please enter a 10 digit mobile number.";
                return false;
            } else {
                mobileError.textContent = "";
                return true;
            }
        }

        if (mobileInput) {
            mobileInput.addEventListener('input', validateMobile);
        }

        if (studentForm) {
            studentForm.addEventListener('submit', function (event) {
                const isMobileValid = validateMobile();
                const isPasswordValid = validatePassword();
                if (!isMobileValid || !isPasswordValid) {
                    event.preventDefault(); // Stop form submission if validation fails
                }
            });
        }

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
        // Address field character count
        const cityInput = document.getElementById('city');
        const cityCharCount = document.getElementById('cityCharCount');
        const maxLength = 255;

        function updateCityCharCount() {
            const currentLength = cityInput.value.length;
            const remaining = maxLength - currentLength;

            if (remaining === 0) {
                cityCharCount.textContent = "Address exceeds the maximum character limit.";
                cityCharCount.style.color = 'red';
            } else if (remaining < 0) { // Should not happen with maxlength, but good for robustness
                cityCharCount.textContent = "Address exceeds the maximum character limit.";
                cityCharCount.style.color = 'red';
            } else {
                cityCharCount.textContent = `${remaining}`; // Removed "Characters remaining: "
                if (remaining <= 10) {
                    cityCharCount.style.color = 'red';
                } else {
                    cityCharCount.style.color = 'green';
                }
            }
        }

        if (cityInput && cityCharCount) {
            updateCityCharCount(); // Set initial count
            cityInput.addEventListener('input', updateCityCharCount);
        }

    });
</script>
</body>
</html>



