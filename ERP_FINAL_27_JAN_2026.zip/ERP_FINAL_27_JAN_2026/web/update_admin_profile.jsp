<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%
    Connection conn = null;
    PreparedStatement pstmt = null;
    String message = "";
    boolean success = false;

    try {
        String id = request.getParameter("id");
        String currentPassword = request.getParameter("current_password");
        String newPassword = request.getParameter("new_password");
        String confirmPassword = request.getParameter("confirm_password");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        String city = request.getParameter("city");

        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

        // Get current password from DB
        pstmt = conn.prepareStatement("SELECT passord FROM adminMaster WHERE id=?");
        pstmt.setInt(1, Integer.parseInt(id));
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            String dbPassword = rs.getString("passord");

            if (dbPassword.equals(currentPassword)) {
                // Current password matches, proceed with updates
                
                String passwordToUpdate = dbPassword; // By default, keep the old password

                if (newPassword != null && !newPassword.isEmpty()) {
                    if (newPassword.equals(confirmPassword)) {
                        passwordToUpdate = newPassword;
                    } else {
                        message = "New passwords do not match.";
                        // The rest of the page will show the error
                    }
                }

                if (message.isEmpty()) { // Only update if no password mismatch
                    pstmt = conn.prepareStatement("UPDATE adminMaster SET passord=?, email=?, mobile=?, city=? WHERE id=?");
                    pstmt.setString(1, passwordToUpdate);
                    pstmt.setString(2, email);
                    pstmt.setString(3, mobile);
                    pstmt.setString(4, city);
                    pstmt.setInt(5, Integer.parseInt(id));

                    int rowsAffected = pstmt.executeUpdate();
                    if (rowsAffected > 0) {
                        success = true;
                        message = "Profile updated successfully!";
                    } else {
                        message = "Failed to update profile. Please try again.";
                    }
                }

            } else {
                message = "Incorrect current password. Profile not updated.";
            }
        } else {
            message = "Admin user not found.";
        }

    } catch (Exception e) {
        message = "An error occurred: " + e.getMessage();
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
        if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
    }

    if (success) {
        response.sendRedirect("DisplayMessages_1.jsp?status=success&message=" + java.net.URLEncoder.encode(message, "UTF-8"));
    } else {
%>
<html>
<head>
    <title>Update Failed</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <div class="container">
        <div class="form-container text-center">
            <h2>Update Failed</h2>
            <p style="color:red;"><%= message %></p>
            <a href="edit_admin_profile.jsp" class="btn">Try Again</a>
        </div>
    </div>
</body>
</html>
<%
    }
%>
