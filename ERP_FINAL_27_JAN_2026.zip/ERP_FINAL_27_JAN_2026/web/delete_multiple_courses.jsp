<%@ page import="java.sql.*" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    String[] courseIds = request.getParameterValues("courseIds");
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    List<String> successMessages = new ArrayList<>();
    List<String> errorMessages = new ArrayList<>();

    if (courseIds != null && courseIds.length > 0) {
        try {
            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            for (String courseId : courseIds) {
                String courseName = "";
                try {
                    // Get course name for detailed error message
                    pstmt = conn.prepareStatement("SELECT nam FROM CourseMaster WHERE id = ?");
                    pstmt.setString(1, courseId);
                    rs = pstmt.executeQuery();
                    if (rs.next()) {
                        courseName = rs.getString("nam");
                    }
                    closeQuietly(rs);
                    closeQuietly(pstmt);

                    // Attempt to delete the course
                    pstmt = conn.prepareStatement("DELETE FROM CourseMaster WHERE id = ?");
                    pstmt.setString(1, courseId);
                    int result = pstmt.executeUpdate();
                    if (result > 0) {
                        successMessages.add("Course '" + courseName + "' deleted successfully.");
                    } else {
                        errorMessages.add("Course '" + courseName + "' could not be found. It may have been deleted already.");
                    }
                } catch (SQLIntegrityConstraintViolationException e) {
                    errorMessages.add("Course '" + courseName + "' cannot be deleted because it is currently assigned to one or more students.");
                } catch (SQLException e) {
                    errorMessages.add("A database error occurred for course '" + courseName + "': " + e.getMessage());
                } finally {
                    closeQuietly(rs);
                    closeQuietly(pstmt);
                }
            }
        } catch (Exception e) {
            errorMessages.add("An unexpected error occurred: " + e.getMessage());
        } finally {
            closeQuietly(conn);
        }
    } else {
        errorMessages.add("No courses selected for deletion.");
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Multiple Courses | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <nav class="navbar">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="form-container text-center">
            <% if (!successMessages.isEmpty()) { %>
                <h2>Deletion Summary</h2>
                <div style="color: green;">
                    <% for (String message : successMessages) { %>
                        <p><%= message %></p>
                    <% } %>
                </div>
            <% } %>
            <% if (!errorMessages.isEmpty()) { %>
                <h2 style="color: red;">Deletion Failed for Some Courses</h2>
                <div style="color: red;">
                    <% for (String message : errorMessages) { %>
                        <p><%= message %></p>
                    <% } %>
                </div>
            <% } %>
            <a href="viewallcourse.jsp" class="btn">View All Courses</a>
        </div>
    </div>
</body>
</html>