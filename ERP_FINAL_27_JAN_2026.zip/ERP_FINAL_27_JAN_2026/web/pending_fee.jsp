<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.Statement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ include file="auth.jsp" %>

<%
    String studentUsername = (String) session.getAttribute("username");
    String studentMobile = "";
    String studentEmail = "";
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    String errorMessage = null;
    double totalPendingAmount = 0;
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System - Pending Fee</title>
    <link rel="stylesheet" href="new_style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="DisplayMessages.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages.jsp">Home</a></li>
            <li><a href="pending_fee.jsp" class="active">Pending Fee</a></li>
            <li><a href="profile.jsp">My Enrollments</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">


        <% try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

            // Get student mobile and email
            PreparedStatement userPstmt = conn.prepareStatement("SELECT mobile, email FROM studentMaster WHERE name = ?");
            userPstmt.setString(1, studentUsername);
            ResultSet userRs = userPstmt.executeQuery();
            if (userRs.next()) {
                studentMobile = userRs.getString("mobile");
                studentEmail = userRs.getString("email");
            }
            userRs.close();
            userPstmt.close();

            // --- 2. Fetch Student Enrollment Details ---
            String enrollmentQuery = "SELECT CourseMaster.nam AS courseName, CourseMaster.DURATION AS courseDuration, " +
                                     "CourseMaster.technology AS courseTechnology, CourseMaster.fees AS totalFee, " +
                                     "IFNULL(feepaid.amount, 0) AS feePaid " +
                                     "FROM studentMaster " +
                                     "INNER JOIN CoursesEnrolled ON CoursesEnrolled.studentid = studentMaster.id " +
                                     "INNER JOIN CourseMaster ON CoursesEnrolled.courseid = CourseMaster.id " +
                                     "LEFT JOIN feepaid ON feepaid.id = CoursesEnrolled.eid " +
                                     "WHERE studentMaster.name = ? AND (CourseMaster.fees - IFNULL(feepaid.amount, 0)) > 0 " +
                                     "ORDER BY CASE CourseMaster.nam " +
                                     "WHEN 'Playgroup' THEN 1 " +
                                     "WHEN 'Nursery' THEN 2 " +
                                     "WHEN 'LKG' THEN 3 " +
                                     "WHEN 'UKG' THEN 4 " +
                                     "WHEN 'Class I' THEN 5 " +
                                     "WHEN 'Class II' THEN 6 " +
                                     "WHEN 'Class III' THEN 7 " +
                                     "WHEN 'Class IV' THEN 8 " +
                                     "WHEN 'Class V' THEN 9 " +
                                     "WHEN 'Class VI' THEN 10 " +
                                     "WHEN 'Class VII' THEN 11 " +
                                     "WHEN 'Class VIII' THEN 12 " +
                                     "WHEN 'Class IX' THEN 13 " +
                                     "WHEN 'Class X' THEN 14 " +
                                     "WHEN 'Class XI' THEN 15 " +
                                     "WHEN 'Class XII' THEN 16 " +
                                     "ELSE 17 END DESC LIMIT 1";
            pstmt = conn.prepareStatement(enrollmentQuery);
            pstmt.setString(1, studentUsername);
            rs = pstmt.executeQuery();
            
            boolean hasEnrollments = false;
            // Check if there are any enrollments to display
            if (rs.isBeforeFirst()) { // Check if ResultSet is not empty
                hasEnrollments = true;
                
                // First pass: Calculate total pending amount
                rs.beforeFirst(); // Ensure cursor is at the beginning
                while (rs.next()) {
                    totalPendingAmount += (rs.getInt("totalFee") - rs.getInt("feePaid"));
                }

                // Reset cursor to the beginning for displaying the table
                rs.beforeFirst(); 
        %>
                <div style="color: red; text-align: center; margin-bottom: 15px; font-weight: bold;">
                    
                </div>
                <h3 class="text-center">Pending Fee</h3>
                <div class="download-buttons" style="margin-bottom: 10px;">
                    <button onclick="downloadPdf()" class="btn">Download PDF</button>
                    <a href="download_pending_fees.jsp?format=csv" class="btn">Download CSV</a>
                </div>
                <div class="total-pending-amount" style="margin-bottom: 20px; text-align: right; font-size: 1.2em; font-weight: bold;">
                    Total pending amount to Pay: Rs <%= String.format("%.2f", totalPendingAmount) %>
                </div>
                <table class="content-table" id="enrollments-table">
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Duration</th>
                            <th>Subject</th>
                            <th>Total Fee</th>
                            <th>Fee Paid</th>
                            <th>Fee Remaining</th>

                        </tr>
                    </thead>
                    <tbody>
                        <% while (rs.next()) { 
                            int feeRemaining = rs.getInt("totalFee") - rs.getInt("feePaid");
                        %>
                            <tr>
                                <td><%= rs.getString("courseName") %></td>
                                <td><%= rs.getInt("courseDuration") %> months</td>
                                <td><%= rs.getString("courseTechnology") %></td>
                                <td>Rs <%= rs.getInt("totalFee") %></td>
                                <td>Rs <%= rs.getInt("feePaid") %></td>
                                <td>Rs <%= feeRemaining %></td>

                            </tr>
                        <% } %>
                    </tbody>
                </table>
        <%
            }

            if (!hasEnrollments && errorMessage == null) {
                errorMessage = "No courses enrolled yet.";
            }
        
        } catch (Exception e) {
            errorMessage = "Database Error: " + e.getMessage();
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException e) { /* ignored */ }
            if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
        }

        if (errorMessage != null) {
        %>
            <div class="form-container text-center" style="margin-top: 20px;">
                <h3 style="color: red;">Error:</h3>
                <p><%= errorMessage %></p>
            </div>
        <%
        }
        %>
    </div>

    <script>
        function downloadPdf() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            const pageWidth = doc.internal.pageSize.getWidth();

            // Add title
            doc.setFontSize(18);
            doc.text("Junior Kids Learn Fee Details", 14, 22);

            // Add date and time on the top right
            const today = new Date();
            const dateOptions = { day: '2-digit', month: 'long', year: 'numeric' };
            const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }; // Use 24-hour format

            const datePart = today.toLocaleDateString('en-GB', dateOptions);
            const timePart = today.toLocaleTimeString('en-GB', timeOptions); // Using 'en-GB' locale for consistent time format

            const dateStr = "Date: " + datePart + " (" + timePart + ")";
            doc.setFontSize(10);
            doc.setTextColor(100);
            doc.text(dateStr, pageWidth - 14, 22, { align: 'right' });


            // Add student info
            doc.setFontSize(11);
            doc.setTextColor(100);
            doc.text("Name: <%= studentUsername %>", 14, 32);
            doc.text("Phone: <%= studentMobile %>", 14, 38);
            doc.text("Email: <%= studentEmail %>", 14, 44);

            // Add table
            doc.autoTable({
                html: '#enrollments-table',
                startY: 54,
                theme: 'grid',
                headStyles: { fillColor: [22, 160, 133] },
            });
            
            // Add total pending amount
            const finalY = doc.autoTable.previous.finalY;
            doc.setFontSize(12);
            doc.setFont('helvetica', 'bold');
            doc.text("Total pending amount to Pay: Rs <%= String.format("%.2f", totalPendingAmount) %>", 14, finalY + 15);


            // Add Signature of teacher
            doc.setFontSize(10);
            doc.setFont('helvetica', 'bold');
            doc.text("Signature of teacher with date", 30, doc.internal.pageSize.getHeight() - 20);

            // Create filename
            const filenameBase = "<%= studentUsername %>_<%= studentMobile %>_Enrollment.pdf";
            const safeFilename = filenameBase.replace(/[^a-zA-Z0-9._-]/g, '_');

            // Save the PDF
            doc.save(safeFilename);
        }
    </script>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</html>