<%
    Integer adminId = (Integer) session.getAttribute("admin_id");
    String username = (String) session.getAttribute("username");
    if (adminId == null && !"admin".equals(username)) {
        response.sendRedirect("home.jsp");
    }
%>
