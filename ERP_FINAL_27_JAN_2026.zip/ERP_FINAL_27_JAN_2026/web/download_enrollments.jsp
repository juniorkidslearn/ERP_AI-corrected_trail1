<%@ page trimDirectiveWhitespaces="true" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.IOException" %>
<%@ include file="auth.jsp" %>
<%
    String format = request.getParameter("format");
    String studentUsername = (String) session.getAttribute("username");

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

        // Get student mobile for filename
        String studentMobile = "";
        PreparedStatement userPstmt = null;
        ResultSet userRs = null;
        try {
            userPstmt = conn.prepareStatement("SELECT mobile FROM studentMaster WHERE name = ?");
            userPstmt.setString(1, studentUsername);
            userRs = userPstmt.executeQuery();
            if (userRs.next()) {
                studentMobile = userRs.getString("mobile");
            }
        } finally {
            if (userRs != null) userRs.close();
            if (userPstmt != null) userPstmt.close();
        }

        // Sanitize and create filename
        String filenameBase = studentUsername + "_" + (studentMobile != null ? studentMobile : "") + "_Enrollment";
        String safeFilename = filenameBase.replaceAll("[^a-zA-Z0-9._-]", "_");

        String enrollmentQuery = "SELECT CourseMaster.nam AS courseName, CourseMaster.DURATION AS courseDuration, " +
                                 "CourseMaster.technology AS courseTechnology, CourseMaster.fees AS totalFee, " +
                                 "IFNULL(feepaid.amount, 0) AS feePaid " +
                                 "FROM studentMaster " +
                                 "INNER JOIN CoursesEnrolled ON CoursesEnrolled.studentid = studentMaster.id " +
                                 "INNER JOIN CourseMaster ON CoursesEnrolled.courseid = CourseMaster.id " +
                                 "LEFT JOIN feepaid ON feepaid.id = CoursesEnrolled.eid " +
                                 "WHERE studentMaster.name = ? " +
                                 "ORDER BY CASE CourseMaster.nam " +
                                     "WHEN 'Playgroup' THEN 1 " +
                                     "WHEN 'Nursery' THEN 2 " +
                                     "WHEN 'LKG' THEN 3 " +
                                     "WHEN 'UKG' THEN 4 " +
                                     "WHEN 'Class I' THEN 5 " +
                                     "WHEN 'Class II' THEN 6 " +
                                     "WHEN 'Class III' THEN 7 " +
                                     "WHEN 'Class IV' THEN 8 " +
                                     "WHEN 'Class V' THEN 9 " +
                                     "WHEN 'Class VI' THEN 10 " +
                                     "WHEN 'Class VII' THEN 11 " +
                                     "WHEN 'Class VIII' THEN 12 " +
                                     "WHEN 'Class IX' THEN 13 " +
                                     "WHEN 'Class X' THEN 14 " +
                                     "WHEN 'Class XI' THEN 15 " +
                                     "WHEN 'Class XII' THEN 16 " +
                                     "ELSE 17 END DESC";
        pstmt = conn.prepareStatement(enrollmentQuery);
        pstmt.setString(1, studentUsername);
        rs = pstmt.executeQuery();

        if ("csv".equals(format)) {
            response.reset();
            response.setContentType("text/csv");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + safeFilename + ".csv\"");
            // CSV Header
            out.println("Class,Subject");
            while (rs.next()) {
                out.print("\"" + rs.getString("courseName") + "\",");
                out.println("\"" + rs.getString("courseTechnology") + "\"");
            }
        } else if ("pdf".equals(format)) {
            response.reset();
            // PDF generation is more complex and usually requires a library like iText.
            // For now, we'll output a simple message.
            response.setContentType("text/html");
            out.println("<html><body>");
            out.println("<h1>PDF Download</h1>");
            out.println("<p>PDF generation for " + safeFilename + ".pdf is not yet implemented. Here is the data:</p>");
            out.println("<table border='1'>");
            out.println("<tr><th>Course Name</th><th>Duration</th><th>Technology</th><th>Total Fee</th><th>Fee Paid</th><th>Fee Remaining</th></tr>");
            while (rs.next()) {
                int feeRemaining = rs.getInt("totalFee") - rs.getInt("feePaid");
                out.println("<tr>");
                out.println("<td>" + rs.getString("courseName") + "</td>");
                out.println("<td>" + rs.getInt("courseDuration") + " months</td>");
                out.println("<td>" + rs.getString("courseTechnology") + "</td>");
                out.println("<td>Rs " + rs.getInt("totalFee") + "</td>");
                out.println("<td>Rs " + rs.getInt("feePaid") + "</td>");
                out.println("<td>Rs " + feeRemaining + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");
            out.println("</body></html>");

        } else {
            response.sendRedirect("profile.jsp");
        }

    } catch (Exception e) {
        // Handle exception
        response.setContentType("text/html");
        out.println("<html><body><h3>Error</h3><p>" + e.getMessage() + "</p></body></html>");
        e.printStackTrace(response.getWriter());
    } finally {
        if (rs != null) try { rs.close(); } catch (SQLException e) { /* ignored */ }
        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
        if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
    }
%>
