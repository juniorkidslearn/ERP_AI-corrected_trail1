<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // Redirect if not a POST request
    if (!"POST".equalsIgnoreCase(request.getMethod())) {
        response.sendRedirect("addcourse.jsp");
        return;
    }

    // Input parameters
    String nam = request.getParameter("nam");
    String duration = request.getParameter("duration");
    String technology = request.getParameter("technology");
    String feesStr = request.getParameter("fees");

    // State variables
    String errorMessage = null;
    int fees = 0;


    // Resource declarations
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    // Validate input
    if (nam == null || nam.trim().isEmpty() ||
        duration == null || duration.trim().isEmpty() ||
        technology == null || technology.trim().isEmpty() ||
        feesStr == null || feesStr.trim().isEmpty()) {
        errorMessage = "All fields are required. Please fill out the form completely and try again.";
    } else {
        try {
            // Validate and parse fees
            fees = Integer.parseInt(feesStr);

            // Establish connection
            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Check for duplicate course name
            String checkQuery = "SELECT COUNT(*) FROM CourseMaster WHERE Nam = ?";
            PreparedStatement checkPstmt = conn.prepareStatement(checkQuery);
            checkPstmt.setString(1, nam);
            rs = checkPstmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                errorMessage = "A course with the name '" + nam + "' already exists. Please choose a different name.";
            } else {
                try { // Add a try-catch block for parsing duration
                    int parsedDuration = Integer.parseInt(duration); // Parse duration here

                    // Insert new course using PreparedStatement
                    String query = "INSERT INTO CourseMaster(Nam, duration, technology, fees) VALUES (?, ?, ?, ?)";
                    pstmt = conn.prepareStatement(query);
                    pstmt.setString(1, nam);
                    pstmt.setInt(2, parsedDuration); // Use parsedDuration
                    pstmt.setString(3, technology);
                    pstmt.setInt(4, fees);

                    if (pstmt.executeUpdate() > 0) {
                        response.sendRedirect("viewallcourse.jsp?status=success");
                        return;
                    } else {
                        errorMessage = "The course could not be added due to a server error. Please try again.";
                    }
                } catch (NumberFormatException e) {
                    errorMessage = "Invalid input for Duration. Please enter a valid number.";
                }
            }
        } catch (NumberFormatException e) {
            errorMessage = "Invalid input for fees. Please enter a valid number.";
        } catch (ClassNotFoundException e) {
            errorMessage = "Database driver not found. Please ensure the MySQL driver is correctly installed.";
        } catch (SQLException e) {
            errorMessage = "A database error occurred: " + e.getMessage();
        } catch (Exception e) {
            errorMessage = "An unexpected error occurred: " + e.getMessage();
        } finally {
            // Clean up resources
            closeQuietly(pstmt);
            closeQuietly(conn);
        }
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <nav class="navbar">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li class="dropdown">
                <a href="#">Course</a>
                <div class="dropdown-content">
                    <a href="viewallcourse.jsp">View Course</a>
                    <a href="addcourse.jsp" class="active">Add New Course</a>
                    <a href="modifycourse.jsp">Modify Course</a>
                    <a href="deletecourse.jsp">Delete Course</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Students</a>
                <div class="dropdown-content">
                    <a href="viewallstudent.jsp">View Students</a>
                    <a href="addstudent.jsp">Add New Student</a>
                    <a href="modifystudent.jsp">Modify Student</a>
                    <a href="deletestudent.jsp">Delete Student</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% if (errorMessage != null) { %>
            <div class="form-container" style="text-align: center;">
                <h2>Error Adding Course</h2>
                <p style="color: red;"><%= errorMessage %></p>
                <a href="addcourse.jsp" class="btn">Try Again</a>
            </div>
        <% } %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>