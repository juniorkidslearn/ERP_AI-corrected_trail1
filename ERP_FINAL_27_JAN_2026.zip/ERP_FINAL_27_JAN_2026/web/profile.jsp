<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.Statement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ include file="auth.jsp" %>

<%
    String studentUsername = (String) session.getAttribute("username");
    String studentMobile = "";
    String studentEmail = "";
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    String errorMessage = null;
    double totalPendingAmount = 0;
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System - Profile</title>
    <link rel="stylesheet" href="new_style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <style>
        .tab-buttons {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .tab-button {
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
            margin: 0 5px;
            border-radius: 5px;
        }
        .tab-button.active {
            background-color: #4CAF50;
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
    </style>
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="DisplayMessages.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages.jsp">Home</a></li>
            <li><a href="pending_fee.jsp">Pending Fee</a></li>
            <li><a href="profile.jsp" class="active">My Enrollments</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="tab-buttons">
            <button class="tab-button active" onclick="showTab('enrollments')">My Enrollments</button>
            <button class="tab-button" onclick="showTab('payment-history')">Payment History</button>
        </div>

        <div id="enrollments-content" class="tab-content active">
            <% try {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

                // Get student mobile and email
                PreparedStatement userPstmt = conn.prepareStatement("SELECT mobile, email FROM studentMaster WHERE name = ?");
                userPstmt.setString(1, studentUsername);
                ResultSet userRs = userPstmt.executeQuery();
                if (userRs.next()) {
                    studentMobile = userRs.getString("mobile");
                    studentEmail = userRs.getString("email");
                }
                userRs.close();
                userPstmt.close();

                // --- 2. Fetch Student Enrollment Details ---
                String enrollmentQuery = "SELECT CourseMaster.nam AS courseName, CourseMaster.DURATION AS courseDuration, " +
                                         "CourseMaster.technology AS courseTechnology, CourseMaster.fees AS totalFee, " +
                                         "IFNULL(feepaid.amount, 0) AS feePaid " +
                                         "FROM studentMaster " +
                                         "INNER JOIN CoursesEnrolled ON CoursesEnrolled.studentid = studentMaster.id " +
                                         "INNER JOIN CourseMaster ON CoursesEnrolled.courseid = CourseMaster.id " +
                                         "LEFT JOIN feepaid ON feepaid.id = CoursesEnrolled.eid " +
                                         "WHERE studentMaster.name = ? " +
                                         "ORDER BY CASE CourseMaster.nam " +
                                         "WHEN 'Playgroup' THEN 1 " +
                                         "WHEN 'Nursery' THEN 2 " +
                                         "WHEN 'LKG' THEN 3 " +
                                         "WHEN 'UKG' THEN 4 " +
                                         "WHEN 'Class I' THEN 5 " +
                                         "WHEN 'Class II' THEN 6 " +
                                         "WHEN 'Class III' THEN 7 " +
                                         "WHEN 'Class IV' THEN 8 " +
                                         "WHEN 'Class V' THEN 9 " +
                                         "WHEN 'Class VI' THEN 10 " +
                                         "WHEN 'Class VII' THEN 11 " +
                                         "WHEN 'Class VIII' THEN 12 " +
                                         "WHEN 'Class IX' THEN 13 " +
                                         "WHEN 'Class X' THEN 14 " +
                                         "WHEN 'Class XI' THEN 15 " +
                                         "WHEN 'Class XII' THEN 16 " +
                                         "ELSE 17 END DESC";
                pstmt = conn.prepareStatement(enrollmentQuery);
                pstmt.setString(1, studentUsername);
                rs = pstmt.executeQuery();
                
                boolean hasEnrollments = false;
                // Check if there are any enrollments to display
                if (rs.isBeforeFirst()) { // Check if ResultSet is not empty
                    hasEnrollments = true;
                    
                    // First pass: Calculate total pending amount
                    rs.beforeFirst(); // Ensure cursor is at the beginning
                    while (rs.next()) {
                        totalPendingAmount += (rs.getInt("totalFee") - rs.getInt("feePaid"));
                    }

                    // Reset cursor to the beginning for displaying the table
                    rs.beforeFirst(); 
            %>
                    <h3 class="text-center">My Enrollments(All Classes)</h3>
                    <div class="download-buttons" style="margin-bottom: 10px;">
                        <button onclick="downloadPdf()" class="btn">Download PDF</button>
                        <a href="download_enrollments.jsp?format=csv" class="btn">Download CSV</a>
                    </div>

                    <table class="content-table" id="enrollments-table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Class</th>
                                                                        <th>Subject</th>
                                                                    </tr>
                                                                </thead>                    <tbody>
                            <% while (rs.next()) { %>
                                <tr>
                                    <td><%= rs.getString("courseName") %></td>
                                    <td><%= rs.getString("courseTechnology") %></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
            <%
                }

                if (!hasEnrollments && errorMessage == null) {
                    errorMessage = "No courses enrolled yet.";
                }
            
            } catch (Exception e) {
                errorMessage = "Database Error: " + e.getMessage();
            } finally {
                if (rs != null) try { rs.close(); } catch (SQLException e) { /* ignored */ }
                if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
                if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
            }

            if (errorMessage != null) {
            %>
                <div class="form-container text-center" style="margin-top: 20px;">
                    <h3 style="color: red;">Error:</h3>
                    <p><%= errorMessage %></p>
                </div>
            <%
            }
            %>
        </div>
        <div id="payment-history-content" class="tab-content">
            <h3 class="text-center">Fee Payment History</h3>
            <p class="text-center">Your payment records</p>
            <%
                Connection conn_ph = null;
                PreparedStatement pstmt_ph = null;
                ResultSet rs_ph = null;
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conn_ph = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

                    String paymentHistoryQuery = "SELECT ph.amount, ph.payment_date, cm.nam AS courseName " +
                                                 "FROM payment_history ph " +
                                                 "JOIN CoursesEnrolled ce ON ph.enrollment_id = ce.eid " +
                                                 "JOIN studentMaster sm ON ce.studentid = sm.id " +
                                                 "JOIN CourseMaster cm ON ce.courseid = cm.id " +
                                                 "WHERE sm.name = ? " +
                                                 "ORDER BY ph.payment_date DESC";
                    pstmt_ph = conn_ph.prepareStatement(paymentHistoryQuery);
                    pstmt_ph.setString(1, studentUsername);
                    rs_ph = pstmt_ph.executeQuery();

                    if (rs_ph.isBeforeFirst()) {
            %>
            <table class="content-table" id="payment-history-table">
                <thead>
                    <tr>
                        <th>Payment</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd-MMM-yyyy_HH_mm_ss");
                        while (rs_ph.next()) {
                            String paymentDate = sdf.format(rs_ph.getTimestamp("payment_date"));
                    %>
                    <tr>
                        <td>Payment_for_<%= rs_ph.getString("courseName") %>_on_<%= paymentDate %></td>
                        <td><%= rs_ph.getBigDecimal("amount") %></td>
                    </tr>
                    <%
                        }
                    %>
                </tbody>
            </table>
            <%
                    } else {
            %>
            <p class="text-center">No payment history found.</p>
            <%
                    }
                } catch (Exception e) {
            %>
            <p class="text-center" style="color: red;">Database Error: <%= e.getMessage() %></p>
            <%
                } finally {
                    if (rs_ph != null) try { rs_ph.close(); } catch (SQLException e) { /* ignored */ }
                    if (pstmt_ph != null) try { pstmt_ph.close(); } catch (SQLException e) { /* ignored */ }
                    if (conn_ph != null) try { conn_ph.close(); } catch (SQLException e) { /* ignored */ }
                }
            %>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            var i;
            var tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            var tablinks = document.getElementsByClassName("tab-button");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabName + "-content").style.display = "block";
            event.currentTarget.className += " active";
        }

        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('enrollments-content').style.display = 'block';
        });

        function downloadPdf() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            const pageWidth = doc.internal.pageSize.getWidth();

            // Add title
            doc.setFontSize(18);
            doc.text("Junior Kids Learn Enrollment Details", 14, 22);

            // Add date and time on the top right
            const today = new Date();
            const dateOptions = { day: '2-digit', month: 'long', year: 'numeric' };
            const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }; // Use 24-hour format

            const datePart = today.toLocaleDateString('en-GB', dateOptions);
            const timePart = today.toLocaleTimeString('en-GB', timeOptions); // Using 'en-GB' locale for consistent time format

            const dateStr = "Date: " + datePart + " (" + timePart + ")";
            doc.setFontSize(10);
            doc.setTextColor(100);
            doc.text(dateStr, pageWidth - 14, 22, { align: 'right' });


            // Add student info
            doc.setFontSize(11);
            doc.setTextColor(100);
            doc.text("Name: <%= studentUsername %>", 14, 32);
            doc.text("Phone: <%= studentMobile %>", 14, 38);
            doc.text("Email: <%= studentEmail %>", 14, 44);

            // Add table
            doc.autoTable({
                html: '#enrollments-table',
                startY: 54,
                theme: 'grid',
                headStyles: { fillColor: [22, 160, 133] },
            });
            



            // Create filename
            const filenameBase = "<%= studentUsername %>_<%= studentMobile %>_Enrollment.pdf";
            const safeFilename = filenameBase.replace(/[^a-zA-Z0-9._-]/g, '_');

            // Save the PDF
            doc.save(safeFilename);
        }
    </script>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</html>