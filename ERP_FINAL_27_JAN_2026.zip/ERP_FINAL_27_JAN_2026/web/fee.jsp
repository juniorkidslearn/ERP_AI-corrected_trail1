<%@ include file="admin_auth.jsp" %>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp" class="active">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <%@page import="java.sql.Statement"%>
        <%@page import="java.sql.ResultSet"%>
        <%@page import="java.sql.Connection"%>
        <%@page import="java.sql.DriverManager"%>
        <%@page contentType="text/html" pageEncoding="UTF-8"%>

        <%
          String selectedEmployeeId = request.getParameter("selectedEmployee");
          Connection conn = null;
          String url="jdbc:mysql://localhost:3306/";
          String dbName ="database2";
          String  driver="com.mysql.jdbc.Driver";
          String userName="root";
          String password="";
          Statement st;
          try{
              Class.forName(driver).newInstance();
              conn= DriverManager.getConnection(url+dbName,userName,password);
              st=conn.createStatement();
              String quer="SELECT * FROM studentMaster";
              ResultSet rs = st.executeQuery(quer);
        %>
        <div class="form-container">
            <h2 class="text-center">Manage Fees</h2>
            <form method="get" action="fee_1.jsp">
                <div class="form-group">
                    <label for="selectedEmployee">Select The Student</label>
                    <select name="selectedEmployee" id="selectedEmployee" class="form-control" onchange="this.form.submit()">
                        <option value="">-- Select Student --</option>
                        <% while(rs.next()){ 
                           String studentId = rs.getString("id");
                           String selected = (studentId.equals(selectedEmployeeId)) ? "selected" : "";
                        %>
                        <option value="<%= studentId %>" <%= selected %>><%=rs.getString("name")%>, <%=rs.getString("mobile")%>, <%=rs.getString("email")%>, <%=rs.getString("city")%></option>
                        <%  }  %>
                    </select>
                </div>
                <div class="form-group text-center">
                    <input type="submit" value="FETCH" class="btn">
                </div>
            </form>
        </div>
        <%
          }
          catch(Exception e){out.println(e);}
        %>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const studentSelect = document.getElementById('selectedEmployee');
        if(studentSelect) {
            const choices = new Choices(studentSelect, {
                searchEnabled: true,
                itemSelectText: 'Press to select',
            });
        }

        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</html>



