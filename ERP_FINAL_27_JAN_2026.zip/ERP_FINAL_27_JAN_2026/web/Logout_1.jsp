<%-- 
    Document   : Logout
    Created on : Dec 15, 2018, 10:50:25 AM
    Author     : HP
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Invalidate session to clear all attributes
    session.invalidate();
    // Redirect to home page
    response.sendRedirect("home.jsp");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="0;url=home.jsp">
    <title>Logging Out...</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <div class="container">
        <div class="form-container text-center">
            <h2>Logging Out</h2>
            <p>You have been successfully logged out. You will be redirected shortly.</p>
            <p>If you are not redirected, <a href="home.jsp" class="btn">click here</a>.</p>
        </div>
    </div>
</body>
</html>