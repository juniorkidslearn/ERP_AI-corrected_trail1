<%
    session.removeAttribute("username");
    response.sendRedirect("home.jsp");
%>
