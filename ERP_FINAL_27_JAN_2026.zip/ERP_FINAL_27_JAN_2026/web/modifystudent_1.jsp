<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // State variables
    String studentIdStr = request.getParameter("selectedStudent");
    if (studentIdStr == null) {
        studentIdStr = request.getParameter("id");
    }
    String message = null;
    boolean isError = false;
    boolean showForm = false;

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    // Handle POST request for modification
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("id") != null) {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String password = request.getParameter("passord");
            String email = request.getParameter("email");
            String mobile = request.getParameter("mobile");
            String city = request.getParameter("city");

            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Get the current student's name
            String currentStudentName = null;
            PreparedStatement pstmtFetchName = null;
            ResultSet rsFetchName = null;
            try {
                pstmtFetchName = conn.prepareStatement("SELECT Name FROM studentMaster WHERE id = ?");
                pstmtFetchName.setInt(1, id);
                rsFetchName = pstmtFetchName.executeQuery();
                if (rsFetchName.next()) {
                    currentStudentName = rsFetchName.getString("Name");
                }
            } finally {
                closeQuietly(rsFetchName);
                closeQuietly(pstmtFetchName);
            }

            // Check if the new name already exists for a different student
            PreparedStatement pstmtCheckName = null;
            ResultSet rsCheckName = null;
            boolean nameExists = false;

            if (!name.equalsIgnoreCase(currentStudentName)) { // Only check if the name has actually changed
                try {
                    pstmtCheckName = conn.prepareStatement("SELECT COUNT(*) FROM studentMaster WHERE Name = ? AND id != ?");
                    pstmtCheckName.setString(1, name);
                    pstmtCheckName.setInt(2, id);
                    rsCheckName = pstmtCheckName.executeQuery();
                    if (rsCheckName.next() && rsCheckName.getInt(1) > 0) {
                        nameExists = true;
                    }
                } finally {
                    closeQuietly(rsCheckName);
                    closeQuietly(pstmtCheckName);
                }
            }

            if (nameExists) {
                message = "Student name '" + name + "' already exists. Please choose a different name.";
                isError = true;
            } else {
                String query = "UPDATE studentMaster SET Name=?, passord=?, email=?, mobile=?, city=? WHERE id=?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, name);
                pstmt.setString(2, password);
                pstmt.setString(3, email);
                pstmt.setString(4, mobile);
                pstmt.setString(5, city);
                pstmt.setInt(6, id);

                if (pstmt.executeUpdate() > 0) {
                    message = "Student details updated successfully!";
                } else {
                    message = "Failed to update student. They may no longer exist.";
                    isError = true;
                }
            }
        } catch (Exception e) {
            message = "An error occurred during modification: " + e.getMessage();
            isError = true;
        } finally {
            closeQuietly(pstmt);
            closeQuietly(conn);
        }
    }

    // Show form for selected student
    if (studentIdStr != null && !studentIdStr.isEmpty()) {
        showForm = true;
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Student | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
                        <li class="active"><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li style="float:right"><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% if (message != null) { %>
            <div class="form-container text-center" style="border-color: <%= isError ? "red" : "green" %>;">
                <h2 style="color: <%= isError ? "red" : "green" %>;"><%= isError ? "Update Failed" : "Update Successful" %></h2>
                <p><%= message %></p>
                <a href="modifystudent_1.jsp?id=<%= request.getParameter("id") %>" class="btn">Try Again</a>
                <a href="viewallstudent.jsp" class="btn">View All Students</a>
            </div>
        <% } %>

        <% if (showForm && message == null) {
            try {
                int studentId = Integer.parseInt(studentIdStr);
                Class.forName(DB_DRIVER);
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                pstmt = conn.prepareStatement("SELECT * FROM studentMaster WHERE id = ?");
                pstmt.setInt(1, studentId);
                rs = pstmt.executeQuery();

                if (rs.next()) {
        %>
                    <div class="form-container">
                        <h2 class="text-center">Modify Student Details</h2>
                        <form method="post" action="modifystudent_1.jsp">
                            <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" value="<%= rs.getString("name") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="passord">Password</label>
                                <input type="password" id="passord" name="passord" value="<%= rs.getString("passord") %>" required>
                                <span id="passwordError" style="color: red; font-size: 0.8em;"></span>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<%= rs.getString("email") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="mobile">Mobile</label>
                                <input type="number" id="mobile" name="mobile" value="<%= rs.getString("mobile") %>" min="0" required pattern="[0-9]{10}" title="Please enter a 10 digit mobile number." maxlength="10" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">
                                <span id="mobileError" style="color: red; font-size: 0.8em;"></span>
                            </div>
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" id="city" name="city" value="<%= rs.getString("city") %>" required>
                            </div>
                            <div class="form-group text-center">
                                <input type="submit" value="UPDATE STUDENT" class="btn">
                            </div>
                        </form>
                    </div>
        <%
                } else {
                    out.println("<p class='text-center' style='color:red;'>Student not found.</p>");
                }
            } catch (Exception e) {
                out.println("<p class='text-center' style='color:red;'>Error fetching student details: " + e.getMessage() + "</p>");
            } finally {
                closeQuietly(rs);
                closeQuietly(pstmt);
                closeQuietly(conn);
            }
        } else if (!showForm) {
        %>
            <div class="form-container text-center">
                <h2>No Student Selected</h2>
                <p>Please go back and select a student to modify.</p>
                <a href="modifystudent.jsp" class="btn">Go Back</a>
            </div>
        <% } %>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        const mobileInput = document.getElementById('mobile');
        const mobileError = document.getElementById('mobileError');
        const studentForm = document.querySelector('.form-container form'); // Assuming there's only one form

        const passwordInput = document.getElementById('passord');
        const passwordError = document.getElementById('passwordError');

        function validatePassword() {
            const pass = passwordInput.value;
            passwordError.textContent = ""; // Clear previous errors

            if (pass === '') {
                passwordError.textContent = "Password is required.";
                return false;
            }

            if (pass.length < 8) {
                passwordError.textContent = "Password must be at least 8 characters long.";
                return false;
            }
            if (!/[A-Z]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one uppercase letter.";
                return false;
            }
            if (!/[a-z]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one lowercase letter.";
                return false;
            }
            if (!/[0-9]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one number.";
                return false;
            }
            if (!/[^a-zA-Z0-9]/.test(pass)) {
                passwordError.textContent = "Password must contain at least one special character.";
                return false;
            }

            return true; // All validations passed
        }

        if (passwordInput) {
            passwordInput.addEventListener('input', validatePassword);
        }

        function validateMobile() {
            const mobileValue = mobileInput.value;
            if (!/^\d{10}$/.test(mobileValue)) {
                mobileError.textContent = "Please enter a 10 digit mobile number.";
                return false;
            } else {
                mobileError.textContent = "";
                return true;
            }
        }

        if (mobileInput) {
            mobileInput.addEventListener('input', validateMobile);
        }

        if (studentForm) {
            studentForm.addEventListener('submit', function (event) {
                const isMobileValid = validateMobile();
                const isPasswordValid = validatePassword();
                if (!isMobileValid || !isPasswordValid) {
                    event.preventDefault(); // Stop form submission if validation fails
                }
            });
        }

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>