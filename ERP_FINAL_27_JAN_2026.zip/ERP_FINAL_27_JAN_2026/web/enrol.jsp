<%@ include file="admin_auth.jsp" %>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp" class="active">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <%@page import="java.sql.Statement"%>
        <%@page import="java.sql.ResultSet"%>
        <%@page import="java.sql.Connection"%>
        <%@page import="java.sql.DriverManager"%>
        <%@page contentType="text/html" pageEncoding="UTF-8"%>

        <%
          Connection conn = null;
          String url="jdbc:mysql://localhost:3306/";
          String dbName ="database2";
          String driver="com.mysql.jdbc.Driver";
          String userName="root";
          String password="";
          Statement st_course, st_student;
          try{
              Class.forName(driver).newInstance();
              conn= DriverManager.getConnection(url+dbName,userName,password);
              st_course = conn.createStatement();
              st_student = conn.createStatement();
              String quer_course="SELECT * from CourseMaster;";
              ResultSet rs_course = st_course.executeQuery(quer_course);
              String quer_student="SELECT * from studentMaster;";
              ResultSet rs_student = st_student.executeQuery(quer_student);
        %>
        <div class="form-container">
            <h2 class="text-center">Enrol Student</h2>
            <form method="post" action="enrol_1.jsp">
                <div class="form-group">
                    <label for="selectedstudent">Select the student to enroll</label>
                    <select name="selectedstudent" id="selectedstudent" class="form-control">
                        <% while(rs_student.next()){  %>
                        <option value="<%=rs_student.getInt("id")%>"><%=rs_student.getString("name")%>, <%=rs_student.getString("mobile")%>, <%=rs_student.getString("email")%>, <%=rs_student.getString("city")%></option>
                        <% } %>
                    </select>
                </div>
                <div class="form-group">
                    <label for="selectedcourse">Select the class to optain</label>
                    <select name="selectedcourse" id="selectedcourse" class="form-control">
                        <% while(rs_course.next()){  %>
                        <option value="<%=rs_course.getInt("id")%>"><%=rs_course.getString("nam")%></option>
                        <% }
                           rs_course.beforeFirst(); // Reset cursor to the beginning
                        %>
                    </select>
                </div>
                <div class="form-group">
                    <label for="selectedfees">Fee</label>
                    <select name="selectedfees_display" id="selectedfees" class="form-control" disabled>
                        <% while(rs_course.next()){  %>
                        <option value="<%=rs_course.getInt("id")%>">Rs <%=rs_course.getInt("fees")%></option>
                        <% } %>
                    </select>
                    <input type="hidden" name="selectedfees" id="selectedfees_hidden">
                </div>
                <div class="form-group text-center">
                    <input type="submit" value="ENROL" class="btn">
                </div>
            </form>
        </div>
        <%
          }
          catch(Exception e){out.println(e);}
        %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const studentSelect = document.getElementById('selectedstudent');
        if(studentSelect) {
            const choicesStudent = new Choices(studentSelect, {
                searchEnabled: true,
                itemSelectText: 'Press to select',
            });
        }

        const courseSelectElement = document.getElementById('selectedcourse');
        if(courseSelectElement) {
            const choicesCourse = new Choices(courseSelectElement, {
                searchEnabled: true,
                itemSelectText: 'Press to select',
            });
        }

        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });

        // Sync fee dropdown with course dropdown
        const courseSelect = document.getElementById('selectedcourse');
        const feeSelect = document.getElementById('selectedfees');
        const feeHiddenInput = document.getElementById('selectedfees_hidden');

        if (courseSelect && feeSelect && feeHiddenInput) {
            function updateFee() {
                const selectedCourseId = courseSelect.value;
                feeSelect.value = selectedCourseId;
                feeHiddenInput.value = feeSelect.options[feeSelect.selectedIndex].text.replace('Rs ', '');
            }

            courseSelect.addEventListener('change', updateFee);

            // Trigger the update on page load to sync them initially
            updateFee();
        }
    });
</script>
</body>
</html>