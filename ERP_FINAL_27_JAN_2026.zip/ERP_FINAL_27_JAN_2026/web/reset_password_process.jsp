<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page import="java.sql.DriverManager" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System - Password Reset Process</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="home.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="home.jsp">Home</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="form-container">
            <%
                String email = request.getParameter("email");
                String name = request.getParameter("name");
                String errorMessage = null;

                if (email == null || email.trim().isEmpty() || name == null || name.trim().isEmpty()) {
                    errorMessage = "Email and Username are required.";
                } else {
                    Connection conn = null;
                    PreparedStatement pstmt = null;
                    ResultSet rs = null;
                    try {
                        Class.forName("com.mysql.jdbc.Driver");
                        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

                        String query = "SELECT id FROM studentMaster WHERE email = ? AND name = ?";
                        pstmt = conn.prepareStatement(query);
                        pstmt.setString(1, email);
                        pstmt.setString(2, name);
                        rs = pstmt.executeQuery();

                        if (rs.next()) {
                            // User found, proceed to password update page
                            int studentId = rs.getInt("id");
                            response.sendRedirect("update_password.jsp?studentId=" + studentId);
                            return; // Stop further processing
                        } else {
                            errorMessage = "No matching user found with the provided email and username.";
                        }
                    } catch (Exception e) {
                        errorMessage = "Database Error: " + e.getMessage();
                    } finally {
                        if (rs != null) try { rs.close(); } catch (SQLException e) { /* ignored */ }
                        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
                        if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
                    }
                }
            %>
            <h2 class="text-center">Password Reset</h2>
            <p style="color: red;" class="text-center"><%= errorMessage %></p>
            <p class="text-center"><a href="forgot_password.jsp" class="btn btn-danger">Try Again</a></p>
            <p class="text-center"><a href="home.jsp">Back to Login</a></p>
        </div>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</html>
