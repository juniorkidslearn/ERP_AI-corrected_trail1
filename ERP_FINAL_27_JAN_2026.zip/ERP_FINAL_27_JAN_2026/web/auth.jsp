<% String user = (String) session.getAttribute("username"); if (user == null) { response.sendRedirect("home.jsp"); } %>
