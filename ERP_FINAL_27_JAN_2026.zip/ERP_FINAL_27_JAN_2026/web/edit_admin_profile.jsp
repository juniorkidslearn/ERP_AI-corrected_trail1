<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Admin Profile | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages_1.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% 
            try {
                // adminId is already declared and checked in admin_auth.jsp
                // We can safely use it here.
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");
                pstmt = conn.prepareStatement("SELECT * FROM adminMaster WHERE id = ?");
                pstmt.setInt(1, adminId); // Use the adminId from admin_auth.jsp
                rs = pstmt.executeQuery();

                if (rs.next()) {
        %>
                    <div class="form-container">
                        <h2 class="text-center">Modify Your Details</h2>
                        <form method="post" action="update_admin_profile.jsp">
                            <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" value="<%= rs.getString("Name") %>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password">
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password">
                                <span id="passwordError" style="color: red; font-size: 0.8em;"></span>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<%= rs.getString("email") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="mobile">Mobile</label>
                                <input type="number" id="mobile" name="mobile" value="<%= rs.getString("mobile") %>" required pattern="[0-9]{10}" title="Please enter a 10 digit mobile number." maxlength="10" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">
                                <span id="mobileError" style="color: red; font-size: 0.8em;"></span>
                            </div>
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" id="city" name="city" value="<%= rs.getString("city") %>" required>
                            </div>
                            <div class="form-group text-center">
                                <input type="submit" value="UPDATE PROFILE" class="btn">
                            </div>
                        </form>
                    </div>
        <%
                } else {
                    out.println("<p class='text-center' style='color:red;'>Admin not found.</p>");
                }
            } catch (Exception e) {
                out.println("<p class='text-center' style='color:red;'>Error fetching admin details: " + e.getMessage() + "</p>");
            } finally {
                if (rs != null) try { rs.close(); } catch (Exception e) { /* ignored */ }
                if (pstmt != null) try { pstmt.close(); } catch (Exception e) { /* ignored */ }
                if (conn != null) try { conn.close(); } catch (Exception e) { /* ignored */ }
            }
        %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click
        const mobileInput = document.getElementById('mobile');
        const mobileError = document.getElementById('mobileError');
        const adminForm = document.querySelector('.form-container form'); // Assuming there's only one form
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');
        const passwordError = document.getElementById('passwordError');

        function validatePassword() {
            const newPass = newPassword.value;
            const confirmPass = confirmPassword.value;
            passwordError.textContent = ""; // Clear previous errors

            // If new password fields are left empty, and old password is provided,
            // assume no password change is intended.
            // However, if newPass is empty and confirmPass is not, it's an error.
            if (newPass === '' && confirmPass === '') {
                return true; // No new password is being set, valid by default
            }

            if (newPass !== confirmPass) {
                passwordError.textContent = "New passwords do not match.";
                return false;
            }

            if (newPass.length < 8) {
                passwordError.textContent = "Password must be at least 8 characters long.";
                return false;
            }
            if (!/[A-Z]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one uppercase letter.";
                return false;
            }
            if (!/[a-z]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one lowercase letter.";
                return false;
            }
            if (!/[0-9]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one number.";
                return false;
            }
            if (!/[^a-zA-Z0-9]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one special character.";
                return false;
            }

            return true; // All validations passed
        }
        
        function validateMobile() {
            const mobileValue = mobileInput.value;
            if (!/^\d{10}$/.test(mobileValue)) {
                mobileError.textContent = "Please enter a 10 digit mobile number.";
                return false;
            } else {
                mobileError.textContent = "";
                return true;
            }
        }

        if (mobileInput) {
            mobileInput.addEventListener('input', validateMobile);
        }

        if (adminForm) {
            adminForm.addEventListener('submit', function (event) {
                if (!validateMobile() || !validatePassword()) {
                    event.preventDefault(); // Stop form submission if validation fails
                }
            });
        }

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>
