<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // Input parameters
    String studentIdStr = request.getParameter("selectedstudent");
    String courseIdStr = request.getParameter("selectedcourse");
    String feeIdStr = request.getParameter("selectedfees");

    // State variables
    String errorMessage = null;
    boolean success = false;

    // Resource declarations
    Connection conn = null;
    PreparedStatement checkStmt = null;
    PreparedStatement enrolStmt = null;
    PreparedStatement feeStmt = null;
    ResultSet rs = null;

    // Validate input
    if (studentIdStr == null || studentIdStr.trim().isEmpty() ||
        courseIdStr == null || courseIdStr.trim().isEmpty() ||
        feeIdStr == null || feeIdStr.trim().isEmpty()) {
        errorMessage = "All fields are required. Please select a student, course, and fee.";
    } else {
        try {
            int studentId = Integer.parseInt(studentIdStr);
            int courseId = Integer.parseInt(courseIdStr);
            int feeId = Integer.parseInt(feeIdStr);

            // Establish connection
            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            conn.setAutoCommit(false); // Start transaction

            // 1. Check if the student is already enrolled
            String checkQuery = "SELECT COUNT(*) FROM CoursesEnrolled WHERE studentid = ? AND courseid = ?";
            checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, studentId);
            checkStmt.setInt(2, courseId);
            rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                errorMessage = "This student is already enrolled in the selected course.";
            } else {
                // 2. Enroll the student
                String enrolQuery = "INSERT INTO CoursesEnrolled(studentid, courseid, feeid) VALUES (?, ?, ?)";
                enrolStmt = conn.prepareStatement(enrolQuery);
                enrolStmt.setInt(1, studentId);
                enrolStmt.setInt(2, courseId);
                enrolStmt.setInt(3, feeId);
                int enrolResult = enrolStmt.executeUpdate();

                // 3. Create initial fee record
                String feeQuery = "INSERT INTO feepaid(studentsid, amount) VALUES (?, 0)";
                feeStmt = conn.prepareStatement(feeQuery);
                feeStmt.setInt(1, studentId);
                int feeResult = feeStmt.executeUpdate();

                if (enrolResult > 0 && feeResult > 0) {
                    conn.commit(); // Commit transaction
                    success = true;
                } else {
                    conn.rollback(); // Rollback transaction
                    errorMessage = "Failed to enroll the student. Please try again.";
                }
            }
        } catch (NumberFormatException e) {
            errorMessage = "Invalid selection. Please make a valid choice for student, course, and fee.";
        } catch (ClassNotFoundException e) {
            errorMessage = "Database driver not found. Please ensure the MySQL driver is correctly installed.";
        } catch (SQLException e) {
            conn.rollback(); // Rollback transaction on error
            errorMessage = "A database error occurred: " + e.getMessage();
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback transaction
                } catch (SQLException ex) {
                    // Ignored
                }
            }
            errorMessage = "An unexpected error occurred: " + e.getMessage();
        } finally {
            // Clean up resources
            closeQuietly(rs);
            closeQuietly(checkStmt);
            closeQuietly(enrolStmt);
            closeQuietly(feeStmt);
            if (conn != null) {
                try {
                    conn.setAutoCommit(true); // Restore default behavior
                } catch (SQLException e) {
                    // Ignored
                }
                closeQuietly(conn);
            }
        }
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment Status | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <nav class="navbar">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li class="dropdown">
                <a href="#">Course</a>
                <div class="dropdown-content">
                    <a href="viewallcourse.jsp">View Course</a>
                    <a href="addcourse.jsp">Add New Course</a>
                    <a href="modifycourse.jsp">Modify Course</a>
                    <a href="deletecourse.jsp">Delete Course</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Students</a>
                <div class="dropdown-content">
                    <a href="viewallstudent.jsp">View Students</a>
                    <a href="addstudent.jsp">Add New Student</a>
                    <a href="modifystudent.jsp">Modify Student</a>
                    <a href="deletestudent.jsp">Delete Student</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp" class="active">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="form-container text-center">
            <% if (success) { %>
                <h2 style="color: green;">Student Enrolled Successfully!</h2>
                <p>The student has been enrolled in the course and an initial fee record has been created.</p>
                <a href="enrol.jsp" class="btn">Enroll Another Student</a>
            <% } else { %>
                <h2 style="color: red;">Enrollment Failed</h2>
                <p><%= errorMessage %></p>
                <a href="enrol.jsp" class="btn btn-danger">Try Again</a>
            <% } %>
        </div>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</html>
