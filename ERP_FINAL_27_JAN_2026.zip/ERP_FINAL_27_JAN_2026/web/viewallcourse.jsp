
<%@ include file="admin_auth.jsp" %>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <%
            String status = request.getParameter("status");
            if ("success".equals(status)) {
        %>
                <div class="success-message" style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 10px; margin-bottom: 20px; text-align: center; border-radius: 5px;">
                    Course added successfully!
                </div>
        <%
            }
        %>
        <%@page import="java.sql.Statement"%>
        <%@page import="java.sql.ResultSet"%>
        <%@page import="java.sql.Connection"%>
        <%@page import="java.sql.DriverManager"%>
        <%@page contentType="text/html" pageEncoding="UTF-8"%>

        <%
          Connection conn = null;
          String url="jdbc:mysql://localhost:3306/";
          String dbName ="database2";
          String  driver="com.mysql.jdbc.Driver";
          String userName="root";
          String password="";
          Statement st;
          try{
              Class.forName(driver).newInstance();
              conn= DriverManager.getConnection(url+dbName,userName,password);
              st=conn.createStatement();
              String quer="SELECT * FROM CourseMaster";
              ResultSet rs = st.executeQuery(quer);
        %>
        <h2 class="text-center">All Courses</h2>
        <div class="search-and-table-controls" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
            <div class="search-container">
                <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search for courses..." class="form-control">
            </div>
            <%-- Removed <a href="addcourse.jsp" class="btn">Add New Course</a> from here --%>
        </div>
        <form action="delete_multiple_courses.jsp" method="post">
            <div class="action-buttons-group" style="margin-bottom: 10px;">
                <input type="submit" value="Delete Selected" class="btn btn-danger">
                <a href="addcourse.jsp" class="btn" style="margin-left: 10px;">Add New Course</a>
            </div>
            <table class="content-table" id="courseTable">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th>
                        <th>Class</th>
                        <th>Duration</th>
                        <th>Subjects</th>
                        <th>Fee</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                     while(rs.next()){
                    %>
                    <tr>
                        <td><input type="checkbox" name="courseIds" value="<%=rs.getInt("id")%>"></td>
                        <td><%=rs.getString("nam")%></td>
                        <td><%=rs.getInt("DURATION")%> months</td>
                        <td><%=rs.getString("technology")%></td>
                        <td>Rs <%=rs.getInt("Fees")%></td>
                        <td>
                            <button type="submit" name="id" value="<%=rs.getInt("id")%>" formmethod="get" formaction="modifycourse_1.jsp" class="btn">MODIFY</button>
                            <button type="submit" name="id" value="<%=rs.getInt("id")%>" formmethod="post" formaction="deletecourse_1.jsp" class="btn btn-danger">DELETE</button>
                        </td>
                    </tr>
                    <%  }  %>
                </tbody>
            </table>
        </form>
        <%
          }
          catch(Exception e){out.println(e);}
        %>
    </div>
</body>
<script>
    function searchTable() {
        var input, filter, table, tr, td, i, j, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("courseTable");
        tr = table.getElementsByTagName("tr");

        for (i = 1; i < tr.length; i++) { // Start from 1 to skip the header row
            tr[i].style.display = "none"; // Hide all rows by default

            td = tr[i].getElementsByTagName("td");
            for (j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = ""; // Show the row if a match is found
                        break; // Break inner loop once a match is found in a row
                    }
                }
            }
        }
    }
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
        
        const selectAllCheckbox = document.getElementById('selectAll');
        const checkboxes = document.querySelectorAll('input[name="courseIds"]');

        selectAllCheckbox.addEventListener('change', function () {
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
    });
</script>
</body>
</html>






