create table CourseMaster (id integer auto_increment,Nam varchar(50) not null,
DURATION integer,fees integer  ,TECHNOLOGY varchar(1000),primary key(id));
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Playgroup',12,'Khichdi / Daliya / Curd Rice / Soft Idli',1000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Nursery',12,'Khichdi / Daliya / Curd Rice / Soft Idli',1000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('LKG',12,'Khichdi / Daliya / Curd Rice / Soft Idli',1000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('UKG',12,'Khichdi / Daliya / Curd Rice / Soft Idli',1000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 1',12,'Veg Poha / Upma / Idli–Sambar / Stuffed Soft Paratha',2000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 2',12,'Veg Poha / Upma / Idli–Sambar / Stuffed Soft Paratha',2000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 3',12,'Veg Poha / Upma / Idli–Sambar / Stuffed Soft Paratha',2000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 4',12,'Roti + Sabzi + Dal or Veg Pulao + Curd',2500);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 5',12,'Roti + Sabzi + Dal or Veg Pulao + Curd',3000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 6',12,'Roti + Sabzi + Dal or Veg Pulao + Curd',3000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 7',12,'Roti + Dal + Green Sabzi + Curd / Rajma–Chawal / Egg/Paneer Roll',3500);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 8',12,'Roti + Dal + Green Sabzi + Curd / Rajma–Chawal / Egg/Paneer Roll',3500);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 9',12,'Roti–Sabzi–Dal–Curd–Salad / Sprouts + Roti / Sattu Paratha',3500);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 10',12,'Roti–Sabzi–Dal–Curd–Salad / Sprouts + Roti / Sattu Paratha',4000);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 11',12,'Roti–Sabzi–Dal–Curd–Salad / Sprouts + Roti / Sattu Paratha',4500);
insert into CourseMaster(Nam,DURATION,TECHNOLOGY,fees) values ('Class 12',12,'Roti–Sabzi–Dal–Curd–Salad / Sprouts + Roti / Sattu Paratha',5000);
select * from CourseMaster;

create table studentMaster(ID integer auto_increment,Name varchar(255) not null,passord varchar(255),
email varchar(255),mobile varchar(20),city varchar(255),primary key(id));
insert into studentMaster(name,passord,email,mobile,city) values ('jack','jack123','jack@gmail.com','9234562346','Mithila Colony');
insert into studentMaster(name,passord,email,mobile,city) values ('bob','bob123','bob@gmail.com','9234571237','Mithila Colony');
insert into studentMaster(name,passord,email,mobile,city) values ('satya','satya123','satya@gmail.com','9234892345','Mithila Colony');
select * from studentMaster;

create table adminMaster(ID integer auto_increment,Name varchar(255) not null,passord varchar(255),
email varchar(255),mobile varchar(20),city varchar(255),primary key(id));
insert into adminMaster(name,passord,email,mobile,city) values ('admin','admin123','admin@gmail.com','3478059592','Patna');
select * from adminMaster;

create table payment_history (
id int auto_increment,
enrollment_id int not null,
amount decimal(10, 2) not null,
payment_date datetime default current_timestamp,
primary key(id),
foreign key (enrollment_id) references coursesenrolled(eid)
);
select * from payment_history;

create table CoursesEnrolled (eid integer auto_increment,studentid integer not null,courseid integer not null,feeid integer ,
primary key(eid),Foreign key(courseid) references CourseMaster(id),Foreign key(studentid) references studentMaster(ID));
select * from CoursesEnrolled;

create table feepaid (id integer auto_increment,studentsid integer not null,
amount integer,primary key(id));
select * from feepaid;
