<%@ include file="admin_auth.jsp" %>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp" class="active">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <%@page import="java.sql.Statement"%>
        <%@page import="java.sql.ResultSet"%>
        <%@page import="java.sql.Connection"%>
        <%@page import="java.sql.DriverManager"%>
        <%@page import="java.util.Map"%>
        <%@page import="java.util.List"%>
        <%@page import="java.util.ArrayList"%>
        <%@page import="java.util.HashMap"%>
        <%@page import="java.util.Random"%>
        <%@page contentType="text/html" pageEncoding="UTF-8"%>
        <%
    Connection conn = null;
    String url = "jdbc:mysql://localhost:3306/";
    String dbName = "database2";
    String driver = "com.mysql.jdbc.Driver";
    String userName = "root";
    String password = "";
    Statement st;
    try {
        Class.forName(driver).newInstance();
        conn = DriverManager.getConnection(url + dbName, userName, password);
        st = conn.createStatement();
        String quer = "SELECT s.name, s.email, s.mobile, cm.nam, cm.fees, cm.DURATION AS courseDuration, ce.eid, IFNULL(fp.amount, 0) AS feePaid "
                + "FROM studentMaster s "
                + "JOIN CoursesEnrolled ce ON s.id = ce.studentid "
                + "JOIN CourseMaster cm ON ce.courseid = cm.id "
                + "LEFT JOIN feepaid fp ON ce.eid = fp.id "
                + "ORDER BY s.name, CASE cm.nam "
                + "WHEN 'Playgroup' THEN 16 WHEN 'Nursery' THEN 15 WHEN 'LKG' THEN 14 WHEN 'UKG' THEN 13 "
                + "WHEN 'Class I' THEN 12 WHEN 'Class II' THEN 11 WHEN 'Class III' THEN 10 WHEN 'Class IV' THEN 9 "
                + "WHEN 'Class V' THEN 8 WHEN 'Class VI' THEN 7 WHEN 'Class VII' THEN 6 WHEN 'Class VIII' THEN 5 "
                + "WHEN 'Class IX' THEN 4 WHEN 'Class X' THEN 3 WHEN 'Class XI' THEN 2 WHEN 'Class XII' THEN 1 "
                + "ELSE 17 END";
        ResultSet rs = st.executeQuery(quer);

        // Group enrollments by student
        Map<String, List<Map<String, Object>>> studentEnrollments = new HashMap<>();
        while (rs.next()) {
            String studentName = rs.getString("name");
            Map<String, Object> rowData = new HashMap<>();
            rowData.put("eid", rs.getInt("eid"));
            rowData.put("name", studentName);
            rowData.put("nam", rs.getString("nam"));
            rowData.put("courseDuration", rs.getInt("courseDuration"));
            rowData.put("email", rs.getString("email"));
            rowData.put("mobile", rs.getString("mobile"));
            rowData.put("fees", rs.getInt("fees"));
            rowData.put("feePaid", rs.getInt("feePaid"));

            List<Map<String, Object>> enrollments = studentEnrollments.get(studentName);
            if (enrollments == null) {
                enrollments = new ArrayList<>();
                studentEnrollments.put(studentName, enrollments);
            }
            enrollments.add(rowData);
        }
%>
<h2 class="text-center">Remove Student Enrollment</h2>
<div class="search-container" style="margin-bottom: 20px; text-align: right;">
    <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search for enrollments..." class="form-control" style="width: 300px; display: inline-block;">
</div>
<form method="post" action="removestudent_1.jsp">
    <table class="content-table" id="enrollmentTable">
        <thead>
            <tr>
                <th><input type="checkbox" id="selectAllCheckbox" onclick="toggle(this);"> Select</th>
                <th>Student Name</th>
                <th>Class</th>
                <th>Duration</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Total Fee</th>
                <th>Fee Paid</th>
                <th>Fee Remaining</th>
            </tr>
        </thead>
        <tbody>
            <%
                Random rand = new Random();
                for (Map.Entry<String, List<Map<String, Object>>> entry : studentEnrollments.entrySet()) {
                    List<Map<String, Object>> enrollments = entry.getValue();
                    boolean isMultiEnrolled = enrollments.size() > 1;
                    String studentColor = "rgb(" + (rand.nextInt(128) + 128) + "," + (rand.nextInt(128) + 128) + "," + (rand.nextInt(128) + 128) + ")";
                    boolean isFirstRow = true;

                    for (Map<String, Object> rowData : enrollments) {
                        int totalFee = (int) rowData.get("fees");
                        int feePaid = (int) rowData.get("feePaid");
                        int feeRemaining = totalFee - feePaid;
                        String style = "";
                        if (isMultiEnrolled && !isFirstRow) {
                            style = "style='background-color:" + studentColor + ";'";
                        }
            %>
            <tr <%= style %>>
                <td><input type="checkbox" name="enrollmentIds" value="<%= rowData.get("eid") %>" <%= (isMultiEnrolled && !isFirstRow) ? "checked" : "" %>></td>
                <td><%= rowData.get("name") %></td>
                <td><%= rowData.get("nam") %></td>
                <td><%= rowData.get("courseDuration") %> months</td>
                <td><%= rowData.get("email") %></td>
                <td><%= rowData.get("mobile") %></td>
                <td>Rs <%= totalFee %></td>
                <td>Rs <%= feePaid %></td>
                <td>Rs <%= feeRemaining %></td>
            </tr>
            <%
                        isFirstRow = false;
                    }
                }
            %>
        </tbody>
    </table>
    <div class="form-group text-center">
        <input type="submit" value="REMOVE SELECTED ENROLLMENTS" class="btn btn-danger">
    </div>
</form>
<%
    } catch (Exception e) {
        out.println(e);
    }
%>
            </div>
            <script>
                function toggle(source) {
                    var checkboxes = document.getElementsByName('enrollmentIds');
                    for(var i=0, n=checkboxes.length;i<n;i++) {
                        checkboxes[i].checked = source.checked;
                    }
                }
            
                function searchTable() {
                    var input, filter, table, tr, td, i, j, txtValue;
                    input = document.getElementById("searchInput");
                    filter = input.value.toUpperCase();
                    table = document.getElementById("enrollmentTable");
                    tr = table.getElementsByTagName("tr");
                    
                    for (i = 1; i < tr.length; i++) { // Start from 1 to skip the header row
                        tr[i].style.display = "none"; // Hide all rows by default
                    
                        td = tr[i].getElementsByTagName("td");
                        for (j = 1; j < td.length; j++) { // Start from 1 to skip checkbox column
                            if (td[j]) {
                                txtValue = td[j].textContent || td[j].innerText;
                                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                    tr[i].style.display = ""; // Show the row if a match is found
                                    break;
                                }
                            }
                        }
                    }
                }
            
                document.addEventListener('DOMContentLoaded', function () {
                    const menuToggle = document.querySelector('.menu-toggle');
                    const navLinks = document.querySelector('.nav-links');
                    const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
                    const navbar = document.querySelector('.navbar'); // Added for outside click
            
                    if (menuToggle && navLinks) {
                        menuToggle.addEventListener('click', function () {
                            navLinks.classList.toggle('active');
                            menuToggle.classList.toggle('active');
                        });
            
                        // Close the main menu if a regular link is clicked
                        navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                            link.addEventListener('click', () => {
                                navLinks.classList.remove('active');
                                menuToggle.classList.remove('active');
                                dropdownToggles.forEach(toggle => {
                                    const parentDropdown = toggle.closest('.dropdown');
                                    if (parentDropdown) {
                                        parentDropdown.classList.remove('active');
                                    }
                                });
                            });
                        });
                    }
            
                    // Handle dropdown toggling for mobile
                    dropdownToggles.forEach(toggle => {
                        toggle.addEventListener('click', function (event) {
                            // Only act if navLinks is active (meaning it's mobile view and menu is open)
                            // And prevent default only if it's not a regular click on desktop
                            if (navLinks && navLinks.classList.contains('active')) {
                                event.preventDefault(); // Prevent default link navigation for dropdown parent
                                const parentDropdown = this.closest('.dropdown');
                                if (parentDropdown) {
                                    // Close other open dropdowns at the same level
                                    dropdownToggles.forEach(otherToggle => {
                                        const otherParentDropdown = otherToggle.closest('.dropdown');
                                        if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                            otherParentDropdown.classList.remove('active');
                                        }
                                    });
                                    parentDropdown.classList.toggle('active');
                                }
                            }
                        });
                    });
            
                    // Close dropdowns if main menu is closed
                    if (menuToggle && navLinks) {
                        menuToggle.addEventListener('click', function () {
                            if (!navLinks.classList.contains('active')) {
                                dropdownToggles.forEach(toggle => {
                                    const parentDropdown = toggle.closest('.dropdown');
                                    if (parentDropdown) {
                                        parentDropdown.classList.remove('active');
                                    }
                                });
                            }
                        });
                    }

                    // Added logic to close navbar when clicking outside
                    document.addEventListener('click', function (event) {
                        // Check if the menu is active (open)
                        if (navLinks && navLinks.classList.contains('active')) {
                            // Check if the click was outside the navbar and not on the menu toggle button itself
                            if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                                navLinks.classList.remove('active');
                                menuToggle.classList.remove('active');
                                // Also close any open dropdowns if the main nav is closed this way
                                dropdownToggles.forEach(toggle => {
                                    const parentDropdown = toggle.closest('.dropdown');
                                    if (parentDropdown) {
                                        parentDropdown.classList.remove('active');
                                    }
                                });
                            }
                        }
                    });
                });
            </script>
            </body>
            </html>