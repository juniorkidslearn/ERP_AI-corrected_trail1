<%@ page import="java.sql.*" %>
<%@ page import="java.util.Arrays" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // Input parameter
    String[] enrollmentIdStrs = request.getParameterValues("enrollmentIds");

    // State variables
    String errorMessage = null;
    boolean success = false;
    int deletedCount = 0;

    // Resource declarations
    Connection conn = null;
    PreparedStatement deleteEnrollmentPstmt = null;
    PreparedStatement deleteFeePstmt = null;

    // Validate input
    if (enrollmentIdStrs == null || enrollmentIdStrs.length == 0) {
        errorMessage = "No enrollments were selected for removal. Please choose one or more enrollments and try again.";
    } else {
        try {
            // Establish connection and start transaction
            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            conn.setAutoCommit(false);

            // Create the IN clause string (?,?,?)
            StringBuilder inClause = new StringBuilder();
            for (int i = 0; i < enrollmentIdStrs.length; i++) {
                inClause.append("?");
                if (i < enrollmentIdStrs.length - 1) {
                    inClause.append(",");
                }
            }

            // 1. Delete from CoursesEnrolled
            String deleteEnrollmentQuery = "DELETE FROM CoursesEnrolled WHERE eid IN (" + inClause.toString() + ")";
            deleteEnrollmentPstmt = conn.prepareStatement(deleteEnrollmentQuery);
            for (int i = 0; i < enrollmentIdStrs.length; i++) {
                deleteEnrollmentPstmt.setInt(i + 1, Integer.parseInt(enrollmentIdStrs[i]));
            }
            int enrollmentResult = deleteEnrollmentPstmt.executeUpdate();

            // 2. Delete from feepaid
            String deleteFeeQuery = "DELETE FROM feepaid WHERE id IN (" + inClause.toString() + ")";
            deleteFeePstmt = conn.prepareStatement(deleteFeeQuery);
            for (int i = 0; i < enrollmentIdStrs.length; i++) {
                deleteFeePstmt.setInt(i + 1, Integer.parseInt(enrollmentIdStrs[i]));
            }
            int feeResult = deleteFeePstmt.executeUpdate();

            if (enrollmentResult > 0) {
                conn.commit(); // Commit transaction
                success = true;
                deletedCount = enrollmentResult;
            } else {
                conn.rollback(); // Rollback transaction
                errorMessage = "Could not find the enrollments to remove. They may have already been removed.";
            }
        } catch (NumberFormatException e) {
            errorMessage = "Invalid enrollment ID provided. Please select valid enrollments.";
        } catch (ClassNotFoundException e) {
            errorMessage = "Database driver not found. Please ensure the MySQL driver is correctly installed.";
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                } catch (SQLException ex) {
                    // Log rollback failure
                }
            }
            errorMessage = "A database error occurred: " + e.getMessage();
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                } catch (SQLException ex) {
                    // Log rollback failure
                }
            }
            errorMessage = "An unexpected error occurred: " + e.getMessage();
        } finally {
            // Clean up resources
            closeQuietly(deleteEnrollmentPstmt);
            closeQuietly(deleteFeePstmt);
            if (conn != null) {
                try {
                    conn.setAutoCommit(true); // Restore default
                } catch (SQLException e) {
                    // Ignored
                }
                closeQuietly(conn);
            }
        }
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remove Enrollment | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body>
    <nav class="navbar">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li class="dropdown">
                <a href="#">Course</a>
                <div class="dropdown-content">
                    <a href="viewallcourse.jsp">View Course</a>
                    <a href="addcourse.jsp">Add New Course</a>
                    <a href="modifycourse.jsp">Modify Course</a>
                    <a href="deletecourse.jsp">Delete Course</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Students</a>
                <div class="dropdown-content">
                    <a href="viewallstudent.jsp">View Students</a>
                    <a href="addstudent.jsp">Add New Student</a>
                    <a href="modifystudent.jsp">Modify Student</a>
                    <a href="deletestudent.jsp">Delete Student</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp" class="active">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="form-container text-center">
            <% if (success) { %>
                <h2>Enrollments Removed Successfully</h2>
                <p><%= deletedCount %> enrollment(s) have been successfully removed.</p>
                <a href="removestudent.jsp" class="btn">Remove More Enrollments</a>
            <% } else { %>
                <h2>Removal Failed</h2>
                <p style="color: red;"><%= errorMessage %></p>
                <a href="removestudent.jsp" class="btn">Try Again</a>
            <% } %>
        </div>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>
