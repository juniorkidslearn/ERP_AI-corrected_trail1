<%@ include file="admin_auth.jsp" %>
<% response.sendRedirect("DisplayMessages_1.jsp"); %>
