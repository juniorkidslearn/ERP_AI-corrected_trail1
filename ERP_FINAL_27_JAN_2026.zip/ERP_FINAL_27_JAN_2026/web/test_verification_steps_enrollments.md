### Test Steps to Verify Changes

#### Test Case 1: Verify "My Enrollments" Page

1.  **Login:** Log in to the application as a student enrolled in multiple classes.
2.  **Navigate:** Go to the "My Enrollments" page.
3.  **Verification:**
    *   Check if the table displaying all enrollments is sorted by the "Class" column in descending order based on the specified hierarchy: 'Class XII' > 'Class XI' > ... > 'Playgroup'.
    *   Ensure the "Subject" for each class is displayed correctly.

#### Test Case 2: Verify "Download CSV" for All Enrollments

1.  **Login and Navigate:** Follow steps 1 and 2 from Test Case 1.
2.  **Download:** Click the "Download CSV" button.
3.  **Verification:**
    *   Open the downloaded CSV file.
    *   Verify that the data in the CSV is sorted by the "Class" column in the same descending order as on the "My Enrollments" page.
    *   Confirm that the "Subject" column is correct.

#### Test Case 3: Verify "Pending Fee" Page (No Impact)

1.  **Login:** Log in to the application as a student who has pending fees for multiple classes.
2.  **Navigate:** Go to the "Pending Fee" page.
3.  **Verification:**
    *   Check if the table displaying pending fees is sorted by the "Class" column in descending order based on the specified hierarchy.
    *   Ensure that all other data in the table (Duration, Subject, Total Fee, Fee Paid, Fee Remaining) is correct for each class.
    *   This is to ensure that the "Pending Fee" section is not affected by the changes made for "My Enrollments".

#### Test Case 4: Verify "Download CSV" for Pending Fees (No Impact)

1.  **Login and Navigate:** Follow steps 1 and 2 from Test Case 3.
2.  **Download:** Click the "Download CSV" button.
3.  **Verification:**
    *   Open the downloaded CSV file.
    *   Verify that the data in the CSV is sorted by the "Class" column in the same descending order as on the web page.
    *   Confirm that all other columns and data are correct.
    *   This is to ensure that the "Download CSV" for "Pending Fee" is not affected.
