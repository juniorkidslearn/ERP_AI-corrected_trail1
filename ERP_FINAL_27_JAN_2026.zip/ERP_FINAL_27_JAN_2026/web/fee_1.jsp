<%@ page import="java.sql.*, java.util.*, java.net.URLEncoder" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // State variables
    String studentIdStr = request.getParameter("selectedEmployee");
    String paymentAmountStr = request.getParameter("paymentAmount");
    String enrollmentIdStr = request.getParameter("enrollmentId");
    String message = null;
    boolean isError = false;

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    // Handle POST request for fee payment
    if ("POST".equalsIgnoreCase(request.getMethod()) && studentIdStr != null && paymentAmountStr != null && enrollmentIdStr != null) {
        try {
            int studentId = Integer.parseInt(studentIdStr);
            int paymentAmount = Integer.parseInt(paymentAmountStr);
            int enrollmentId = Integer.parseInt(enrollmentIdStr);

            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Fetch current fee details to validate payment
            String query = "SELECT fees, amount FROM CourseMaster cm JOIN CoursesEnrolled ce ON cm.id = ce.courseid " +
                           "JOIN feepaid fp ON ce.eid = fp.id WHERE ce.studentid = ? AND ce.eid = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, enrollmentId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int totalFees = rs.getInt("fees");
                int amountPaid = rs.getInt("amount");
                if (paymentAmount > (totalFees - amountPaid)) {
                    message = "Payment amount cannot exceed the remaining balance.";
                    isError = true;
                } else {
                    closeQuietly(rs);
                    closeQuietly(pstmt);

                    // Update fee paid amount
                    String updateQuery = "UPDATE feepaid SET amount = amount + ? WHERE id = ?";
                    pstmt = conn.prepareStatement(updateQuery);
                    pstmt.setInt(1, paymentAmount);
                    pstmt.setInt(2, enrollmentId);

                    if (pstmt.executeUpdate() > 0) {
                        // Also insert into payment_history
                        closeQuietly(pstmt);
                        String historyQuery = "INSERT INTO payment_history (enrollment_id, amount) VALUES (?, ?)";
                        pstmt = conn.prepareStatement(historyQuery);
                        pstmt.setInt(1, enrollmentId);
                        pstmt.setInt(2, paymentAmount);
                        pstmt.executeUpdate();

                        message = "Fee payment of Rs " + paymentAmount + " processed successfully!";
                    } else {
                        message = "Failed to process payment. Please try again.";
                        isError = true;
                    }
                }
            } else {
                message = "Could not find enrollment details for the selected student.";
                isError = true;
            }
        } catch (Exception e) {
            message = "An error occurred: " + e.getMessage();
            isError = true;
        } finally {
            closeQuietly(rs);
            closeQuietly(pstmt);
            closeQuietly(conn);
        }

        // Implement Post/Redirect/Get (PRG) pattern
        String redirectURL = "fee_1.jsp?selectedEmployee=" + studentIdStr;
        if (message != null) {
            redirectURL += "&message=" + URLEncoder.encode(message, "UTF-8");
            redirectURL += "&isError=" + isError;
        }
        response.sendRedirect(redirectURL);
        return; // Stop further processing of this JSP
    } else {
        // For GET requests or initial page load, retrieve message from parameters
        message = request.getParameter("message");
        if (request.getParameter("isError") != null) {
            isError = Boolean.parseBoolean(request.getParameter("isError"));
        }
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Fees | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
    <style>
        .filter-bar {
            background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;
            border: 1px solid #dee2e6; display: flex; flex-wrap: wrap; align-items: center; gap: 15px;
        }
        .filter-bar .form-control {
            border-radius: 6px; border: 1px solid #ced4da; padding: 8px 12px;
            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
            height: 40px; flex-grow: 1; min-width: 150px;
        }
        .filter-bar #searchInput { flex-grow: 2; min-width: 200px; }
        .filter-bar .form-control:focus {
            border-color: #80bdff; outline: 0; box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
        .btn-reset {
            background-color: #28a745; border-color: #28a745; color: #fff; text-decoration: none;
            padding: 8px 16px; border-radius: 6px; display: inline-flex; align-items: flex-end;
            justify-content: center; text-align: center; cursor: pointer; user-select: none;
            height: 40px; transition: background-color .15s ease-in-out, border-color .15s ease-in-out;
        }
        .btn-reset:hover { background-color: #218838; border-color: #1e7e34; color: #fff; }

        /* Custom Multi-select Dropdown */
        .multi-select-container {
            position: relative;
            flex-grow: 1;
            min-width: 180px;
        }
        .multi-select-button {
            background-color: #fff;
            border-radius: 6px;
            border: 1px solid #ced4da;
            padding: 8px 12px;
            height: 40px;
            width: 100%;
            text-align: left;
            cursor: pointer;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: flex;
            align-items: center;
        }
        .multi-select-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background-color: #fff;
            border: 1px solid #ced4da;
            border-radius: 6px;
            max-height: 200px;
            overflow-y: auto;
            z-index: 1050;
        }
        .multi-select-dropdown.show {
            display: block;
        }
        .multi-select-dropdown label {
            display: block;
            padding: 8px 12px;
            cursor: pointer;
            user-select: none;
        }
        .multi-select-dropdown label:hover {
            background-color: #f0f0f0;
        }
        .multi-select-dropdown input {
            margin-right: 8px;
        }
    </style>
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% if (message != null) { %>
            <div class="form-container text-center" style="border-color: <%= isError ? "red" : "green" %>;" id="paymentMessage">
                <h2 style="color: <%= isError ? "red" : "green" %>;"><br><%= isError ? "Payment Failed" : "Payment Successful" %></h2>
                <p><%= message %></p>
                <a href="fee.jsp" class="btn">Go Back to Fee Management</a>
            </div>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const paymentMessageDiv = document.getElementById('paymentMessage');
                    if (paymentMessageDiv) {
                        // Scroll initially
                        paymentMessageDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        
                        // Re-scroll after a short delay to account for potential late rendering/layout shifts
                        setTimeout(() => {
                            paymentMessageDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }, 100); // 100ms delay
                    }
                });
            </script>
        <% } %>

        <div class="form-container">
            <h2 class="text-center">Student Fee Details</h2>
            <form method="get" action="fee_1.jsp">
                
                <div class="form-group">
                    <label for="selectedEmployee">Select a Student:</label>
                    <select name="selectedEmployee" id="selectedEmployee" class="form-control">
                        <option value="">-- Select Student --</option>
                        <%
                            try {
                                Class.forName(DB_DRIVER);
                                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                                pstmt = conn.prepareStatement("SELECT * FROM studentMaster ORDER BY Name");
                                rs = pstmt.executeQuery();
                                while (rs.next()) {
                                    String selected = (studentIdStr != null && studentIdStr.equals(rs.getString("ID"))) ? "selected" : "";
                                    out.println("<option value='" + rs.getInt("ID") + "' " + selected + ">" + rs.getString("Name") + ", " + rs.getString("mobile") + ", " + rs.getString("email") + ", " + rs.getString("city") + "</option>");
                                }
                            } catch (Exception e) {
                                // Handle error
                            } finally {
                                closeQuietly(rs);
                                closeQuietly(pstmt);
                                closeQuietly(conn);
                            }
                        %>
                    </select>
                </div>

                <%-- Filter Bar --%>
                <div class="filter-bar" style="margin-bottom: 20px; display: block;">
                    <label style="font-weight: bold; margin-bottom: 5px; display: block;">Filter by Class:</label>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px; padding: 10px; border: 1px solid #ced4da; border-radius: 6px;">
                            <% 
                                List<String> customClassOrder = Arrays.asList(
                                    "Playgroup", "Nursery", "LKG", "UKG", 
                                    "Class I", "Class II", "Class III", "Class IV", 
                                    "Class V", "Class VI", "Class VII", "Class VIII", 
                                    "Class IX", "Class X", "Class XI", "Class XII"
                                );
                                List<String> allClassesFromDB = new ArrayList<>();
                                Connection tempConn = null;
                                Statement tempSt = null;
                                ResultSet rsClasses = null;
                                try {
                                    Class.forName(DB_DRIVER);
                                    tempConn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                                    tempSt = tempConn.createStatement();
                                    rsClasses = tempSt.executeQuery("SELECT DISTINCT Nam FROM CourseMaster ORDER BY Nam");
                                    while (rsClasses.next()) {
                                        allClassesFromDB.add(rsClasses.getString("Nam"));
                                    }
                                } catch (Exception e) {
                                    // Handle error
                                    e.printStackTrace(); // For debugging
                                } finally {
                                    closeQuietly(rsClasses);
                                    closeQuietly(tempSt);
                                    closeQuietly(tempConn);
                                }

                                List<String> sortedClasses = new ArrayList<>();
                                Set<String> classesAdded = new HashSet<>();

                                // Add classes according to custom order
                                for (String cName : customClassOrder) {
                                    if (allClassesFromDB.contains(cName)) {
                                        sortedClasses.add(cName);
                                        classesAdded.add(cName);
                                    }
                                }

                                // Add any remaining classes not in custom order
                                for (String cName : allClassesFromDB) {
                                    if (!classesAdded.contains(cName)) {
                                        sortedClasses.add(cName);
                                    }
                                }

                                String[] selectedClasses = request.getParameterValues("class");
                                Set<String> selectedClassesSet = selectedClasses != null ? new HashSet<String>(Arrays.asList(selectedClasses)) : new HashSet<String>();

                                for (String className : sortedClasses) { 
                            %>
                                    <label>
                                        <input type="checkbox" class="class-filter-checkbox" name="class" value="<%= className %>" <%= selectedClassesSet.contains(className) ? "checked" : "" %>> <%= className %>
                                    </label>
                            <% } %>
                    </div>
                </div>
                </form>

            <div id="feeTableContainer">
                <jsp:include page="fee_details_table_ajax.jsp">
                    <jsp:param name="selectedEmployee" value="<%= studentIdStr != null ? studentIdStr : \"\" %>"/>
                </jsp:include>
            </div>
        </div>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const studentSelect = document.getElementById('selectedEmployee');
        const feeTableContainer = document.getElementById('feeTableContainer');
        const classCheckboxes = document.querySelectorAll('.class-filter-checkbox');

        if(studentSelect) {
            // Initialize Choices.js for the student select
            const choices = new Choices(studentSelect, {
                searchEnabled: true,
                itemSelectText: 'Press to select',
            });
        }

        // Function to update the fee table via AJAX
        async function updateFeeTable(event) {
            const selectedStudentId = studentSelect ? studentSelect.value : '';
            const selectedClasses = Array.from(classCheckboxes)
                                        .filter(checkbox => checkbox.checked)
                                        .map(checkbox => checkbox.value);
            
            // Construct URLSearchParams
            const params = new URLSearchParams();
            if (selectedStudentId) {
                params.append('selectedEmployee', selectedStudentId);
            }
            selectedClasses.forEach(cls => {
                params.append('class', cls);
            });

            // If student dropdown triggered the change, reset class filters
            if (event && event.target && event.target.id === 'selectedEmployee') {
                classCheckboxes.forEach(checkbox => {
                    checkbox.checked = false; // Uncheck all class checkboxes
                });
                // Clear class parameters from URLSearchParams as well
                params.delete('class');
            }

            try {
                if (feeTableContainer) {
                    feeTableContainer.innerHTML = '<p style="text-align:center;">Loading fee details...</p>';
                }
                const response = await fetch('fee_details_table_ajax.jsp?' + params.toString());
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const html = await response.text();
                if (feeTableContainer) {
                    feeTableContainer.innerHTML = html;
                    feeTableContainer.scrollIntoView({ behavior: 'smooth', block: 'start' }); // Scroll to the table
                }
            } catch (error) {
                console.error('Error fetching fee details:', error);
                if (feeTableContainer) {
                    feeTableContainer.innerHTML = '<p style="color:red; text-align:center;">Failed to load fee details. Please try again.</p>';
                }
            }
        }

        // Attach event listeners
        if (studentSelect) {
            studentSelect.addEventListener('change', updateFeeTable);
        }
        classCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateFeeTable);
        });

        // Initial table load
        updateFeeTable();

        // Navbar toggle logic (existing)
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });

    });
</script></html>
