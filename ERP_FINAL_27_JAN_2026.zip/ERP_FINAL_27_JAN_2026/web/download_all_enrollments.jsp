<%@ page trimDirectiveWhitespaces="true" %>
<%@ page import="java.sql.*, java.util.*" %>
<%@ include file="admin_auth.jsp" %>
<% 
    Connection conn = null;
    Statement st = null;
    ResultSet rs = null;

    try {
        // Get filter parameters from request
        String studentIdStr = request.getParameter("selectedEmployee");
        String feeStatus = request.getParameter("fee_status") != null ? request.getParameter("fee_status") : "all";
        String[] selectedClasses = request.getParameterValues("class");
        String colorFilter = request.getParameter("color_filter") != null ? request.getParameter("color_filter") : "all";
        String filename = request.getParameter("filename");

        if (filename == null || filename.isEmpty() || !filename.endsWith(".csv")) {
            filename = "filtered_student_enrollments.csv";
        }

        // Clear any previous output from includes
        response.reset();
        
        // Set CSV headers
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

        // Database connection
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");
        st = conn.createStatement();

        // Base query
        StringBuilder queryBuilder = new StringBuilder(
            "SELECT s.name AS studentName, s.email AS studentEmail, s.mobile AS studentMobile, " +
            "cm.Nam AS courseName, cm.DURATION AS courseDuration, cm.technology AS courseTechnology, " +
            "cm.fees AS totalFee, IFNULL(fp.amount, 0) AS feePaid " +
            "FROM studentMaster s " +
            "JOIN CoursesEnrolled ce ON s.id = ce.studentid " +
            "JOIN CourseMaster cm ON ce.courseid = cm.id " +
            "LEFT JOIN feepaid fp ON ce.eid = fp.id "
        );

        // Dynamic WHERE clause
        List<String> whereClauses = new ArrayList<String>();
        if (studentIdStr != null && !studentIdStr.isEmpty()) {
            whereClauses.add("s.id = " + studentIdStr);
        }
        if (selectedClasses != null && selectedClasses.length > 0) {
            StringBuilder inClause = new StringBuilder();
            for (int i = 0; i < selectedClasses.length; i++) {
                inClause.append("'" + selectedClasses[i].replace("'", "''") + "'");
                if (i < selectedClasses.length - 1) {
                    inClause.append(",");
                }
            }
            whereClauses.add("cm.Nam IN (" + inClause.toString() + ")");
        }
        
        if (!whereClauses.isEmpty()) {
            queryBuilder.append(" WHERE ").append(String.join(" AND ", whereClauses));
        }

        // Dynamic HAVING clause for fee status
        String havingClause = "";
        if ("gt_zero".equals(feeStatus)) {
            havingClause = " HAVING (totalFee - feePaid) > 0";
        } else if ("eq_zero".equals(feeStatus)) {
            havingClause = " HAVING (totalFee - feePaid) = 0";
        } else if ("lt_zero".equals(feeStatus)) {
            havingClause = " HAVING (totalFee - feePaid) < 0";
        }
        queryBuilder.append(havingClause);
        
        // Order by to ensure highest class is first for each student
        queryBuilder.append(" ORDER BY s.name, CASE cm.Nam " +
            "WHEN 'Playgroup' THEN 0 WHEN 'Nursery' THEN 1 WHEN 'LKG' THEN 2 WHEN 'UKG' THEN 3 " +
            "WHEN 'Class I' THEN 4 WHEN 'Class II' THEN 5 WHEN 'Class III' THEN 6 WHEN 'Class IV' THEN 7 " +
            "WHEN 'Class V' THEN 8 WHEN 'Class VI' THEN 9 WHEN 'Class VII' THEN 10 WHEN 'Class VIII' THEN 11 " +
            "WHEN 'Class IX' THEN 12 WHEN 'Class X' THEN 13 WHEN 'Class XI' THEN 14 WHEN 'Class XII' THEN 15 " +
            "ELSE 16 END DESC");

        rs = st.executeQuery(queryBuilder.toString());

        // Write CSV header
        out.println("Student Name,Class,Duration,Email,Phone Number,Subject,Total Fee,Fee Paid,Fee Remaining");

        // --- Logic for writing data ---
        if ("white".equals(colorFilter)) {
            // If filtering for white rows, we must group in Java to get the highest class for each student
            Map<String, List<Map<String, Object>>> studentEnrollments = new LinkedHashMap<String, List<Map<String, Object>>>();
            while (rs.next()) {
                String studentName = rs.getString("studentName");
                Map<String, Object> rowData = new HashMap<String, Object>();
                rowData.put("studentName", rs.getString("studentName"));
                rowData.put("courseName", rs.getString("courseName"));
                rowData.put("courseDuration", rs.getInt("courseDuration"));
                rowData.put("studentEmail", rs.getString("studentEmail"));
                rowData.put("studentMobile", rs.getString("studentMobile"));
                rowData.put("courseTechnology", rs.getString("courseTechnology"));
                rowData.put("totalFee", rs.getInt("totalFee"));
                rowData.put("feePaid", rs.getInt("feePaid"));

                List<Map<String, Object>> enrollments = studentEnrollments.get(studentName);
                if (enrollments == null) {
                    enrollments = new ArrayList<Map<String, Object>>();
                    studentEnrollments.put(studentName, enrollments);
                }
                enrollments.add(rowData);
            }

            for (Map.Entry<String, List<Map<String, Object>>> entry : studentEnrollments.entrySet()) {
                // Get the first entry, which is the highest class due to SQL ORDER BY
                Map<String, Object> rowData = entry.getValue().get(0);
                int totalFee = (Integer) rowData.get("totalFee");
                int feePaid = (Integer) rowData.get("feePaid");
                int feeRemaining = totalFee - feePaid;

                out.print("\"" + rowData.get("studentName") + "\",");
                out.print("\"" + rowData.get("courseName") + "\",");
                out.print(rowData.get("courseDuration") + " months,");
                out.print("\"" + rowData.get("studentEmail") + "\",");
                out.print("\"" + rowData.get("studentMobile") + "\",");
                out.print("\"" + rowData.get("courseTechnology") + "\",");
                out.print(totalFee + ",");
                out.print(feePaid + ",");
                out.println(feeRemaining);
            }
        } else {
            // Original behavior: stream all results directly
            while (rs.next()) {
                int totalFee = rs.getInt("totalFee");
                int feePaid = rs.getInt("feePaid");
                int feeRemaining = totalFee - feePaid;
                
                out.print("\"" + rs.getString("studentName") + "\",");
                out.print("\"" + rs.getString("courseName") + "\",");
                out.print(rs.getInt("courseDuration") + " months,");
                out.print("\"" + rs.getString("studentEmail") + "\",");
                out.print("\"" + rs.getString("studentMobile") + "\",");
                out.print("\"" + rs.getString("courseTechnology") + "\",");
                out.print(totalFee + ",");
                out.print(feePaid + ",");
                out.println(feeRemaining);
            }
        }

    } catch (Exception e) {
        // If an error occurs, it's helpful to see it
        response.reset();
        response.setContentType("text/plain");
        response.setHeader("Content-Disposition", "inline");
        out.println("An error occurred: " + e.getMessage());
        e.printStackTrace(new java.io.PrintWriter(out));
    } finally {
        // Clean up resources
        if (rs != null) try { rs.close(); } catch (SQLException e) {}
        if (st != null) try { st.close(); } catch (SQLException e) {}
        if (conn != null) try { conn.close(); } catch (SQLException e) {}
    }
%>