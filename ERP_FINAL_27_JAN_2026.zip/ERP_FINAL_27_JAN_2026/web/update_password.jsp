<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page import="java.sql.DriverManager" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System - Update Password</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="home.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="home.jsp">Home</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="form-container">
            <h2 class="text-center">Update Password</h2>
            <%
                String studentIdParam = request.getParameter("studentId");
                String errorMessage = null;
                String successMessage = null;

                if (studentIdParam == null || studentIdParam.trim().isEmpty()) {
                    errorMessage = "Invalid request. No student ID provided.";
                } else {
                    int studentId = -1;
                    try {
                        studentId = Integer.parseInt(studentIdParam);
                    } catch (NumberFormatException e) {
                        errorMessage = "Invalid student ID format.";
                    }

                    if (request.getMethod().equalsIgnoreCase("POST") && errorMessage == null) {
                        String newPassword = request.getParameter("newPassword");
                        String confirmPassword = request.getParameter("confirmPassword");

                        if (newPassword == null || newPassword.trim().isEmpty() ||
                            confirmPassword == null || confirmPassword.trim().isEmpty()) {
                            errorMessage = "New password and confirm password fields cannot be empty.";
                        } else if (!newPassword.equals(confirmPassword)) {
                            errorMessage = "New password and confirm password do not match.";
                        } else {
                            Connection conn = null;
                            PreparedStatement pstmt = null;
                            try {
                                Class.forName("com.mysql.jdbc.Driver");
                                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");

                                String updateQuery = "UPDATE studentMaster SET passord = ? WHERE id = ?";
                                pstmt = conn.prepareStatement(updateQuery);
                                pstmt.setString(1, newPassword);
                                pstmt.setInt(2, studentId);

                                int rowsAffected = pstmt.executeUpdate();

                                if (rowsAffected > 0) {
                                    successMessage = "Password updated successfully! You can now log in with your new password.";
                                } else {
                                    errorMessage = "Failed to update password. User not found or no changes made.";
                                }
                            } catch (Exception e) {
                                errorMessage = "Database Error: " + e.getMessage();
                            } finally {
                                if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignored */ }
                                if (conn != null) try { conn.close(); } catch (SQLException e) { /* ignored */ }
                            }
                        }
                    }
            %>
            
            <% if (successMessage != null) { %>
                <p style="color: green;" class="text-center"><%= successMessage %></p>
                <p class="text-center"><a href="home.jsp" class="btn">Go to Login</a></p>
            <% } else { %>
                <% if (errorMessage != null) { %>
                    <p style="color: red;" class="text-center"><%= errorMessage %></p>
                <% } %>
                <form method="post" action="update_password.jsp?studentId=<%= studentId %>" id="passwordForm">
                    <div class="form-group">
                        <label for="newPassword">New Password:</label>
                        <input type="password" id="newPassword" name="newPassword" required>
                        <span id="passwordError" style="color: red; font-size: 0.8em;"></span>
                    </div>
                    <div class="form-group">
                        <label for="confirmPassword">Confirm Password:</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" required>
                        <span id="confirmPasswordError" style="color: red; font-size: 0.8em;"></span>
                    </div>
                    <div class="form-group text-center">
                        <input type="submit" value="Set New Password" class="btn">
                    </div>
                </form>
                <% if (errorMessage != null) { %>
                    <p class="text-center"><a href="forgot_password.jsp" class="btn btn-danger">Start Over</a></p>
                <% } %>
            <% } %>
            <% } // End of if (studentIdParam == null) %>
        </div>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navbar = document.querySelector('.navbar'); // Added for outside click

        const passwordForm = document.getElementById('passwordForm');
        const newPasswordInput = document.getElementById('newPassword');
        const confirmPasswordInput = document.getElementById('confirmPassword');
        const passwordError = document.getElementById('passwordError');
        const confirmPasswordError = document.getElementById('confirmPasswordError');

        function validatePassword() {
            const newPass = newPasswordInput.value;
            const confirmPass = confirmPasswordInput.value;
            passwordError.textContent = ""; // Clear previous errors

            if (newPass === '' && confirmPass === '') {
                return true; // No new password is being set, valid by default
            }

            if (newPass.length < 8) {
                passwordError.textContent = "Password must be at least 8 characters long.";
                return false;
            }
            if (!/[A-Z]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one uppercase letter.";
                return false;
            }
            if (!/[a-z]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one lowercase letter.";
                return false;
            }
            if (!/[0-9]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one number.";
                return false;
            }
            if (!/[^a-zA-Z0-9]/.test(newPass)) {
                passwordError.textContent = "Password must contain at least one special character.";
                return false;
            }

            return true; // All validations passed
        }

        function validateConfirmPassword() {
            const newPass = newPasswordInput.value;
            const confirmPass = confirmPasswordInput.value;
            confirmPasswordError.textContent = ""; // Clear previous errors

            if (newPass !== confirmPass) {
                confirmPasswordError.textContent = "New passwords do not match.";
                return false;
            }

            return true;
        }

        if (newPasswordInput) {
            newPasswordInput.addEventListener('input', validatePassword);
        }

        if (confirmPasswordInput) {
            confirmPasswordInput.addEventListener('input', validateConfirmPassword);
        }

        if (passwordForm) {
            passwordForm.addEventListener('submit', function (event) {
                const isPasswordValid = validatePassword();
                const doPasswordsMatch = validateConfirmPassword();
                if (!isPasswordValid || !doPasswordsMatch) {
                    event.preventDefault(); // Stop form submission if validation fails
                }
            });
        }

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the menu if a link is clicked (for single-page navigation or if desired)
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                });
            });
        }
        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            }
        });
    });
</script>
</html>
