<%@ page import="java.sql.*" %>
<%@ include file="admin_auth.jsp" %>
<%!
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";

    // Helper method to close resources quietly
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // Ignored
            }
        }
    }
%>
<%
    // State variables
    String courseIdStr = request.getParameter("selectedStudent");
    if (courseIdStr == null) {
        courseIdStr = request.getParameter("id");
    }
    String message = null;
    boolean isError = false;
    boolean showForm = false;

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    // Handle POST request for modification
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("id") != null) {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("nam");
            int duration = Integer.parseInt(request.getParameter("DURATION"));
            String technology = request.getParameter("technology");
            int fees = Integer.parseInt(request.getParameter("fees"));

            Class.forName(DB_DRIVER);
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String query = "UPDATE CourseMaster SET Nam=?, DURATION=?, technology=?, fees=? WHERE id=?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setInt(2, duration);
            pstmt.setString(3, technology);
            pstmt.setInt(4, fees);
            pstmt.setInt(5, id);

            if (pstmt.executeUpdate() > 0) {
                message = "Course details updated successfully!";
            } else {
                message = "Failed to update course. It may no longer exist.";
                isError = true;
            }
        } catch (Exception e) {
            message = "An error occurred during modification: " + e.getMessage();
            isError = true;
        } finally {
            closeQuietly(pstmt);
            closeQuietly(conn);
        }
    }

    // Show form for selected course
    if (courseIdStr != null && !courseIdStr.isEmpty()) {
        showForm = true;
    }
%>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Course | Juniorkidslearn's Enrollment System</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
                        <li class="active"><a href="admin.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li style="float:right"><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <% if (message != null) { %>
            <div class="form-container text-center" style="border-color: <%= isError ? "red" : "green" %>;">
                <h2 style="color: <%= isError ? "red" : "green" %>;"><%= isError ? "Update Failed" : "Update Successful" %></h2>
                <p><%= message %></p>
                <a href="viewallcourse.jsp" class="btn">Try Again</a>
                <a href="viewallcourse.jsp" class="btn">View All Courses</a>
            </div>
        <% } %>

        <% if (showForm && message == null) {
            try {
                int courseId = Integer.parseInt(courseIdStr);
                Class.forName(DB_DRIVER);
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                pstmt = conn.prepareStatement("SELECT * FROM CourseMaster WHERE id = ?");
                pstmt.setInt(1, courseId);
                rs = pstmt.executeQuery();

                if (rs.next()) {
        %>
                    <div class="form-container">
                        <h2 class="text-center">Modify Course Details</h2>
                        <form method="post" action="modifycourse_1.jsp">
                            <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
                            <div class="form-group">
                                <label for="nam">Name</label>
                                <input type="text" id="nam" name="nam" value="<%= rs.getString("nam") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="DURATION">Duration (months)</label>
                                <input type="number" id="DURATION" name="DURATION" value="<%= rs.getInt("DURATION") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="technology">Subjects</label>
                                <input type="text" id="technology" name="technology" value="<%= rs.getString("technology") %>" required>
                            </div>
                            <div class="form-group">
                                <label for="fees">Fee</label>
                                <input type="number" id="fees" name="fees" value="<%= rs.getInt("fees") %>" required>
                            </div>
                            <div class="form-group text-center">
                                <input type="submit" value="UPDATE COURSE" class="btn">
                            </div>
                        </form>
                    </div>
        <%
                } else {
                    out.println("<p class='text-center' style='color:red;'>Course not found.</p>");
                }
            } catch (Exception e) {
                out.println("<p class='text-center' style='color:red;'>Error fetching course details: " + e.getMessage() + "</p>");
            } finally {
                closeQuietly(rs);
                closeQuietly(pstmt);
                closeQuietly(conn);
            }
        } else if (!showForm) {
        %>
            <div class="form-container text-center">
                <h2>No Course Selected</h2>
                <p>Please go back and select a course to modify.</p>
                <a href="modifycourse.jsp" class="btn">Go Back</a>
            </div>
        <% } %>
    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>
