<%@ include file="admin_auth.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juniorkidslearn's Enrollment System - Admin Dashboard</title>
    <link rel="stylesheet" href="new_style.css">
</head>
<body style="padding-top: 80px;">
    <nav class="navbar" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1000;">
        <a href="admin.jsp" class="logo">Juniorkidslearn's Enrollment System</a>
        <button class="menu-toggle" aria-label="Toggle navigation menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul class="nav-links">
            <li><a href="DisplayMessages_1.jsp">Home</a></li>
            <li><a href="viewallcourse.jsp">Course</a></li>
            <li><a href="viewallstudent.jsp">Students</a></li>
            <li class="dropdown">
                <a href="#">Enrol</a>
                <div class="dropdown-content">
                    <a href="enrol.jsp">Enrol</a>
                    <a href="removestudent.jsp">Remove</a>
                </div>
            </li>
            <li><a href="view_enrollments.jsp">Enrollment Details</a></li>
            <li><a href="fee.jsp">Fees</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
    <div class="container">
        <div class="form-container text-center">
            <h2>Welcome, Admin!</h2>
            <p>Welcome to the administration panel. You can manage courses, students, and enrollments from the navigation menu.</p>
        </div>
        
        <%
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database2", "root", "");
                
                // adminId is already declared and checked in admin_auth.jsp
                // We can safely use it here.
                String query = "SELECT * FROM adminMaster WHERE ID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, adminId); // Use the adminId from admin_auth.jsp
                rs = pstmt.executeQuery();
                if (rs.next()) {
        %>
        <div class="profile-container" style="margin-top: 20px;">
            <h3 class="text-center">Your Profile</h3>
            <div class="profile-card" style="background-color: #fff; border: 1px solid #ddd; border-radius: 5px; padding: 20px; max-width: 600px; margin: auto;">
                <table class="profile-table" style="width: 100%;">
                    <tr>
                        <td style="font-weight: bold; padding: 10px;">Name:</td>
                        <td style="padding: 10px;"><%= rs.getString("Name") %></td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding: 10px;">Email:</td>
                        <td style="padding: 10px;"><%= rs.getString("email") %></td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding: 10px;">Mobile:</td>
                        <td style="padding: 10px;"><%= rs.getString("mobile") %></td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding: 10px;">City:</td>
                        <td style="padding: 10px;"><%= rs.getString("city") %></td>
                    </tr>
                </table>
                <div class="text-center" style="margin-top: 20px;">
                    <a href="edit_admin_profile.jsp" class="btn">Edit Profile</a>
                </div>
            </div>
        </div>
        <%
                    }
            } catch (Exception e) {
                out.println(e);
            } finally {
                if (rs != null) try { rs.close(); } catch (Exception e) { /* ignored */ }
                if (pstmt != null) try { pstmt.close(); } catch (Exception e) { /* ignored */ }
                if (conn != null) try { conn.close(); } catch (Exception e) { /* ignored */ }
            }
        %>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        const dropdownToggles = document.querySelectorAll('.nav-links .dropdown > a'); // Select direct links of dropdowns
        const navbar = document.querySelector('.navbar'); // Added for outside click

        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                navLinks.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Close the main menu if a regular link is clicked
            navLinks.querySelectorAll('li > a:not(.dropdown > a)').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                });
            });
        }

        // Handle dropdown toggling for mobile
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                // Only act if navLinks is active (meaning it's mobile view and menu is open)
                // And prevent default only if it's not a regular click on desktop
                if (navLinks && navLinks.classList.contains('active')) {
                    event.preventDefault(); // Prevent default link navigation for dropdown parent
                    const parentDropdown = this.closest('.dropdown');
                    if (parentDropdown) {
                        // Close other open dropdowns at the same level
                        dropdownToggles.forEach(otherToggle => {
                            const otherParentDropdown = otherToggle.closest('.dropdown');
                            if (otherParentDropdown && otherParentDropdown !== parentDropdown) {
                                otherParentDropdown.classList.remove('active');
                            }
                        });
                        parentDropdown.classList.toggle('active');
                    }
                }
            });
        });

        // Close dropdowns if main menu is closed
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function () {
                if (!navLinks.classList.contains('active')) {
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Added logic to close navbar when clicking outside
        document.addEventListener('click', function (event) {
            // Check if the menu is active (open)
            if (navLinks && navLinks.classList.contains('active')) {
                // Check if the click was outside the navbar and not on the menu toggle button itself
                if (!navbar.contains(event.target) && event.target !== menuToggle && !menuToggle.contains(event.target)) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                    // Also close any open dropdowns if the main nav is closed this way
                    dropdownToggles.forEach(toggle => {
                        const parentDropdown = toggle.closest('.dropdown');
                        if (parentDropdown) {
                            parentDropdown.classList.remove('active');
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>
